package com.example.ui.hud

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssistantAction
import com.example.ui.theme.ArcBlue
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HudBorderCyan
import com.example.ui.theme.HudSurfaceCard
import com.example.ui.theme.HudSurfaceDark
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.NeonAccentGreen
import com.example.ui.theme.NeonWarningRed

@Composable
fun LiveTranscriptCard(
    userText: String,
    assistantText: String,
    action: AssistantAction?,
    actionStatusMessage: String?,
    isApiKeyMissing: Boolean = false,
    onOpenSettings: () -> Unit = {},
    onReplaySpeech: () -> Unit,
    onExecuteAction: (AssistantAction) -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = userText.isNotBlank() || assistantText.isNotBlank() || isApiKeyMissing,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(HudSurfaceCard.copy(alpha = 0.85f))
                .border(
                    1.dp,
                    if (isApiKeyMissing) Color(0xFFFFB300) else HudBorderCyan,
                    RoundedCornerShape(16.dp)
                )
                .padding(14.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // User Query Section
                if (userText.isNotBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "USER //",
                            color = ArcBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "\"$userText\"",
                            color = HudTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (userText.isNotBlank() && assistantText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(HudBorderCyan.copy(alpha = 0.5f))
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // SABA Response Section
                if (assistantText.isNotBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isApiKeyMissing) "SABA AI // SETUP NOTICE" else "SABA AI //",
                                color = if (isApiKeyMissing) Color(0xFFFFB300) else ElectricCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = assistantText,
                                color = HudTextPrimary,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        }

                        IconButton(
                            onClick = onReplaySpeech,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("replay_speech_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Replay vocal output",
                                tint = if (isApiKeyMissing) Color(0xFFFFB300) else ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // API Key Missing Setup Alert Banner
                if (isApiKeyMissing) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(HudSurfaceDark)
                            .border(1.dp, Color(0xFFFFB300).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .clickable { onOpenSettings() }
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = "API Key Required",
                                    tint = Color(0xFFFFB300),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SETUP: GEMINI_API_KEY NOT CONFIGURED",
                                    color = Color(0xFFFFB300),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Add GEMINI_API_KEY=your_key in 'local.properties' (in root) or configure in AI Studio Secrets. Tap here for instructions.",
                                color = HudTextPrimary.copy(alpha = 0.85f),
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                // Action Notification / Chip if an Android Intent was executed
                if (action != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(ElectricCyan.copy(alpha = 0.12f))
                            .border(1.dp, ElectricCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .clickable { onExecuteAction(action) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("action_result_chip"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Launch,
                            contentDescription = "Triggered Intent Action",
                            tint = NeonAccentGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = actionStatusMessage ?: "INTENT: ${action.type} [${action.payload}]",
                            color = NeonAccentGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
