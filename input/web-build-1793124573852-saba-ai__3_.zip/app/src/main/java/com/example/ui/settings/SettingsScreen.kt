package com.example.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.ui.theme.ArcBlue
import com.example.ui.theme.DeepSpaceBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HudBorderCyan
import com.example.ui.theme.HudSurfaceCard
import com.example.ui.theme.HudSurfaceDark
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.NeonAccentGreen
import com.example.ui.theme.NeonWarningRed

@Composable
fun SettingsScreen(
    voicePitch: Float,
    speechRate: Float,
    language: String,
    memoryEnabled: Boolean,
    contextLimit: Int,
    continuousMode: Boolean,
    isMicPermissionGranted: Boolean,
    onPitchChange: (Float) -> Unit,
    onRateChange: (Float) -> Unit,
    onLanguageChange: (String) -> Unit,
    onMemoryToggle: (Boolean) -> Unit,
    onContextLimitChange: (Int) -> Unit,
    onContinuousModeToggle: (Boolean) -> Unit,
    onRequestMicPermission: () -> Unit,
    onTestVoice: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val hasGeminiApiKey = com.example.util.ConfigHelper.hasValidGeminiApiKey()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepSpaceBlack)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to HUD",
                    tint = ElectricCyan
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text(
                    text = "SYSTEM CONFIGURATION",
                    color = ElectricCyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "VOICE // LANGUAGE // MEMORY // SECURITY",
                    color = HudTextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Wake Phrase & Voice Assistant Mode Section
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ASSISTANT PROTOCOL // \"HEY SABA\"",
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Intended Wake Phrase: \"Hey Saba\".\nTap the central electric-blue microphone to speak. You can say commands like \"Hey Saba, open YouTube\" or \"Camera kholo\".",
                        color = HudTextPrimary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Interactive Continuous Mode",
                                color = HudTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Auto-listen after SABA finishes speaking",
                                color = HudTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = continuousMode,
                            onCheckedChange = onContinuousModeToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = DeepSpaceBlack,
                                checkedTrackColor = ElectricCyan
                            ),
                            modifier = Modifier.testTag("continuous_mode_switch")
                        )
                    }
                }
            }

            // 2. Microphone Permission Status
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = null,
                                tint = if (isMicPermissionGranted) NeonAccentGreen else NeonWarningRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Microphone Permission",
                                    color = HudTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isMicPermissionGranted) "STATUS: GRANTED & ACTIVE" else "STATUS: PERMISSION REQUIRED",
                                    color = if (isMicPermissionGranted) NeonAccentGreen else NeonWarningRed,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        if (!isMicPermissionGranted) {
                            Button(
                                onClick = onRequestMicPermission,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                                modifier = Modifier.testTag("grant_mic_permission_button")
                            ) {
                                Text("GRANT", color = DeepSpaceBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // 3. Voice Synthesizer Settings (TTS)
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "VOCAL SYNTHESIZER CALIBRATION",
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Pitch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Voice Pitch", color = HudTextPrimary, fontSize = 13.sp)
                        Text(
                            text = String.format("%.2fx", voicePitch),
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Slider(
                        value = voicePitch,
                        onValueChange = onPitchChange,
                        valueRange = 0.6f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricCyan,
                            activeTrackColor = ElectricCyan,
                            inactiveTrackColor = HudSurfaceDark
                        ),
                        modifier = Modifier.testTag("voice_pitch_slider")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Speech Rate
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Speech Rate (Speed)", color = HudTextPrimary, fontSize = 13.sp)
                        Text(
                            text = String.format("%.2fx", speechRate),
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Slider(
                        value = speechRate,
                        onValueChange = onRateChange,
                        valueRange = 0.6f..1.6f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricCyan,
                            activeTrackColor = ElectricCyan,
                            inactiveTrackColor = HudSurfaceDark
                        ),
                        modifier = Modifier.testTag("speech_rate_slider")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = onTestVoice,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricCyan),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(ElectricCyan)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_voice_button")
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("TEST SABA VOICE OUTPUT", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // 4. Language Protocol Selector
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LANGUAGE PROTOCOL",
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "SABA natively understands Hindi, Hinglish, and English.",
                        color = HudTextSecondary,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val langs = listOf(
                            "auto" to "Auto-Detect",
                            "hinglish" to "Hinglish",
                            "hi" to "Hindi",
                            "en" to "English"
                        )
                        langs.forEach { (code, label) ->
                            val selected = language == code
                            FilterChip(
                                selected = selected,
                                onClick = { onLanguageChange(code) },
                                label = {
                                    Text(
                                        text = label,
                                        fontSize = 11.sp,
                                        color = if (selected) DeepSpaceBlack else HudTextPrimary
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricCyan,
                                    containerColor = HudSurfaceDark
                                ),
                                modifier = Modifier.testTag("lang_chip_$code")
                            )
                        }
                    }
                }
            }

            // 5. Context Memory Depth & Privacy
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Conversation Context Memory",
                                color = HudTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Recall previous turns for continuous chat",
                                color = HudTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = memoryEnabled,
                            onCheckedChange = onMemoryToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = DeepSpaceBlack,
                                checkedTrackColor = ElectricCyan
                            ),
                            modifier = Modifier.testTag("memory_toggle_switch")
                        )
                    }

                    if (memoryEnabled) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Memory Window (Turns)", color = HudTextPrimary, fontSize = 12.sp)
                            Text(
                                text = "$contextLimit turns",
                                color = ElectricCyan,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Slider(
                            value = contextLimit.toFloat(),
                            onValueChange = { onContextLimitChange(it.toInt()) },
                            valueRange = 2f..20f,
                            steps = 18,
                            colors = SliderDefaults.colors(
                                thumbColor = ElectricCyan,
                                activeTrackColor = ElectricCyan,
                                inactiveTrackColor = HudSurfaceDark
                            ),
                            modifier = Modifier.testTag("context_limit_slider")
                        )
                    }
                }
            }

            // 6. Gemini Neural Core Status & Security Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = if (hasGeminiApiKey) NeonAccentGreen else ArcBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GEMINI NEURAL CORE STATUS",
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (hasGeminiApiKey) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (hasGeminiApiKey) NeonAccentGreen else Color(0xFFFFB300),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (hasGeminiApiKey) "ONLINE // API Key Loaded (${com.example.util.ConfigHelper.getMaskedApiKey()})" else "SETUP REQUIRED // GEMINI_API_KEY NOT FOUND",
                            color = if (hasGeminiApiKey) NeonAccentGreen else Color(0xFFFFB300),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Source: ${com.example.util.ConfigHelper.getKeySourceDescription()}",
                        color = HudTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(HudSurfaceDark)
                            .border(1.dp, HudBorderCyan, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = "HOW TO CONFIGURE API KEY:",
                                color = ElectricCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "1. In your project root, open 'local.properties'\n2. Add: GEMINI_API_KEY=your_gemini_api_key\n3. Rebuild or run app. (Never committed to GitHub - gitignored)\n\nAlternatively, in AI Studio, configure GEMINI_API_KEY in the Secrets panel.",
                                color = HudTextPrimary,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
