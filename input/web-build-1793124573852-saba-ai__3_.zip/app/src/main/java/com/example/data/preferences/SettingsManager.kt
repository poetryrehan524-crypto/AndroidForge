package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("saba_ai_settings", Context.MODE_PRIVATE)

    private val _voicePitch = MutableStateFlow(prefs.getFloat(KEY_PITCH, 1.20f))
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _speechRate = MutableStateFlow(prefs.getFloat(KEY_RATE, 1.0f))
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _language = MutableStateFlow(prefs.getString(KEY_LANGUAGE, "hinglish") ?: "hinglish")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _contextLimit = MutableStateFlow(prefs.getInt(KEY_CONTEXT_LIMIT, 10))
    val contextLimit: StateFlow<Int> = _contextLimit.asStateFlow()

    private val _memoryEnabled = MutableStateFlow(prefs.getBoolean(KEY_MEMORY_ENABLED, true))
    val memoryEnabled: StateFlow<Boolean> = _memoryEnabled.asStateFlow()

    private val _continuousMode = MutableStateFlow(prefs.getBoolean(KEY_CONTINUOUS_MODE, false))
    val continuousMode: StateFlow<Boolean> = _continuousMode.asStateFlow()

    fun setVoicePitch(pitch: Float) {
        val clamped = pitch.coerceIn(0.5f, 2.0f)
        prefs.edit().putFloat(KEY_PITCH, clamped).apply()
        _voicePitch.value = clamped
    }

    fun setSpeechRate(rate: Float) {
        val clamped = rate.coerceIn(0.5f, 2.0f)
        prefs.edit().putFloat(KEY_RATE, clamped).apply()
        _speechRate.value = clamped
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString(KEY_LANGUAGE, lang).apply()
        _language.value = lang
    }

    fun setContextLimit(limit: Int) {
        val clamped = limit.coerceIn(2, 30)
        prefs.edit().putInt(KEY_CONTEXT_LIMIT, clamped).apply()
        _contextLimit.value = clamped
    }

    fun setMemoryEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_MEMORY_ENABLED, enabled).apply()
        _memoryEnabled.value = enabled
    }

    fun setContinuousMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_CONTINUOUS_MODE, enabled).apply()
        _continuousMode.value = enabled
    }

    companion object {
        private const val KEY_PITCH = "voice_pitch"
        private const val KEY_RATE = "speech_rate"
        private const val KEY_LANGUAGE = "language_pref"
        private const val KEY_CONTEXT_LIMIT = "context_limit"
        private const val KEY_MEMORY_ENABLED = "memory_enabled"
        private const val KEY_CONTINUOUS_MODE = "continuous_mode"
    }
}
