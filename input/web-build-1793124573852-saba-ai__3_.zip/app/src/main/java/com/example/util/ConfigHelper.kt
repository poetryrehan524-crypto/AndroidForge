package com.example.util

import com.example.BuildConfig

object ConfigHelper {
    fun getGeminiApiKey(): String {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isNotBlank() && key != "MY_GEMINI_API_KEY") {
                key.trim()
            } else {
                // Secondary fallback via reflection if field is dynamically populated
                val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
                val dynamicKey = (field.get(null) as? String)?.trim() ?: ""
                if (dynamicKey.isNotBlank() && dynamicKey != "MY_GEMINI_API_KEY") dynamicKey else ""
            }
        } catch (e: Throwable) {
            ""
        }
    }

    fun hasValidGeminiApiKey(): Boolean {
        val key = getGeminiApiKey()
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    fun getMaskedApiKey(): String {
        val key = getGeminiApiKey()
        if (key.isBlank()) return "NOT CONFIGURED"
        return if (key.length <= 8) {
            "******"
        } else {
            "${key.take(4)}...${key.takeLast(4)}"
        }
    }

    fun getKeySourceDescription(): String {
        return if (hasValidGeminiApiKey()) {
            "Active: Securely injected into BuildConfig (via local.properties / .env)"
        } else {
            "Missing: Please add GEMINI_API_KEY in local.properties"
        }
    }
}
