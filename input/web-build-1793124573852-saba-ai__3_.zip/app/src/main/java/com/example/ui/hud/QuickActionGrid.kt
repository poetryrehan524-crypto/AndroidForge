package com.example.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HudBorderCyan
import com.example.ui.theme.HudSurfaceCard
import com.example.ui.theme.HudTextSecondary

data class QuickActionItem(
    val title: String,
    val icon: ImageVector,
    val command: String,
    val testTag: String
)

@Composable
fun QuickActionGrid(
    onTriggerCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val actions = listOf(
        QuickActionItem("Suno na Jaan", Icons.Default.Favorite, "Suno na Jaan, kaisa lag raha hai aaj?", "quick_suno_na"),
        QuickActionItem("Khana Khaya?", Icons.Default.Restaurant, "Babu khana khaya tumne?", "quick_khana"),
        QuickActionItem("Selfie Camera", Icons.Default.CameraAlt, "Camera kholo Jaan, selfie leni hai", "quick_camera"),
        QuickActionItem("Romantic Songs", Icons.Default.PlayCircle, "YouTube par romantic songs chalao Babu", "quick_youtube"),
        QuickActionItem("WhatsApp", Icons.AutoMirrored.Filled.Chat, "WhatsApp open kar do", "quick_whatsapp"),
        QuickActionItem("Maps", Icons.Default.Map, "Maps open karo", "quick_maps"),
        QuickActionItem("Calculator", Icons.Default.Calculate, "Calculator open karo", "quick_calc"),
        QuickActionItem("Settings", Icons.Default.Settings, "Open settings", "quick_settings")
    )

    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SWEET SUGGESTIONS // QUICK CONVERSATIONS",
                color = HudTextSecondary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp
            )
        }

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(actions) { item ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(HudSurfaceCard)
                        .border(1.dp, HudBorderCyan, RoundedCornerShape(12.dp))
                        .clickable { onTriggerCommand(item.command) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag(item.testTag)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = item.title,
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
