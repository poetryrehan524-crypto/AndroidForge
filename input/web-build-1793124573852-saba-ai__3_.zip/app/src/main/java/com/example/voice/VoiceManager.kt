package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class VoiceManager(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit
) {
    private val tag = "VoiceManager"
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    private val _statusMessage = MutableStateFlow("SABA IS READY")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var onSpeechDoneCallback: (() -> Unit)? = null

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsInitialized = true
                applyFeminineVoice(Locale("en", "IN"))
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                        _statusMessage.value = "SABA IS SPEAKING..."
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            _isSpeaking.value = false
                            _statusMessage.value = "SABA IS LISTENING"
                            onSpeechDoneCallback?.invoke()
                            onSpeechDoneCallback = null
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            _isSpeaking.value = false
                            _statusMessage.value = "SABA IS READY"
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        mainHandler.post {
                            _isSpeaking.value = false
                            _statusMessage.value = "SABA IS READY"
                        }
                    }
                })
                Log.d(tag, "TTS initialized with warm feminine voice")
            } else {
                Log.e(tag, "Failed to initialize TTS: status=$status")
            }
        }
    }

    private fun applyFeminineVoice(targetLocale: Locale) {
        try {
            val voices = textToSpeech?.voices
            if (!voices.isNullOrEmpty()) {
                val femaleVoice = voices.firstOrNull { voice ->
                    val name = voice.name.lowercase()
                    val matchesLang = voice.locale.language == targetLocale.language
                    matchesLang && (name.contains("female") || name.contains("fem") || name.contains("cfl") || name.contains("f0") || name.contains("#female"))
                } ?: voices.firstOrNull { voice ->
                    val name = voice.name.lowercase()
                    name.contains("female") || name.contains("fem") || name.contains("cfl")
                }
                if (femaleVoice != null) {
                    textToSpeech?.voice = femaleVoice
                }
            }
        } catch (e: Exception) {
            Log.d(tag, "Feminine voice selection fallback: ${e.message}")
        }
    }

    fun startListening(languagePref: String = "hinglish") {
        if (_isSpeaking.value) {
            stopSpeaking()
        }

        mainHandler.post {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                    _statusMessage.value = "SPEECH RECOGNIZER NOT AVAILABLE"
                    return@post
                }

                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

                    when (languagePref) {
                        "hi" -> {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                        }
                        "en" -> {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
                        }
                        else -> {
                            // Hinglish: Accepts Hindi and Indian English naturally
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                            putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayOf("en-IN", "hi-IN", "en-US"))
                        }
                    }
                }

                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                        _statusMessage.value = "SUNO NA JAAN // BOL RAHE HO?"
                    }

                    override fun onBeginningOfSpeech() {
                        _statusMessage.value = "SUN RAHI HOON JAAN..."
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        _audioRms.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _isListening.value = false
                        _audioRms.value = 0f
                        _statusMessage.value = "SOCH RAHI HOON BABU..."
                    }

                    override fun onError(error: Int) {
                        _isListening.value = false
                        _audioRms.value = 0f
                        val reason = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "KUCH SUNAI NAHI DIYA JAAN"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "KOI BAAT NAHI YAAR, PHIR SE BOLO"
                            SpeechRecognizer.ERROR_AUDIO -> "MIC AUDIO ISSUE"
                            SpeechRecognizer.ERROR_CLIENT -> "CLIENT ERROR"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "MIC PERMISSION DEDIJIYE"
                            SpeechRecognizer.ERROR_NETWORK -> "NETWORK PROBLEM"
                            else -> "SABA IS READY"
                        }
                        _statusMessage.value = reason
                    }

                    override fun onResults(results: Bundle?) {
                        _isListening.value = false
                        _audioRms.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spoken = matches?.firstOrNull()?.trim()
                        if (!spoken.isNullOrBlank()) {
                            _statusMessage.value = "ANSWER DE RAHI HOON..."
                            onSpeechResult(spoken)
                        } else {
                            _statusMessage.value = "SABA IS READY"
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()
                        if (!text.isNullOrBlank()) {
                            _statusMessage.value = "HEARING: \"$text\""
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(tag, "Error starting speech recognition", e)
                _isListening.value = false
                _statusMessage.value = "MIC ERROR"
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.e(tag, "Error stopping listener", e)
            }
            _isListening.value = false
            _audioRms.value = 0f
        }
    }

    fun speak(
        text: String,
        pitch: Float = 1.20f,
        speed: Float = 1.0f,
        language: String = "hinglish",
        onDone: (() -> Unit)? = null
    ) {
        if (!isTtsInitialized || text.isBlank()) {
            onDone?.invoke()
            return
        }

        stopListening()
        this.onSpeechDoneCallback = onDone

        try {
            // Warm feminine pitch (1.15f - 1.25f sounds natural, sweet and feminine)
            textToSpeech?.setPitch(pitch.coerceIn(0.6f, 1.8f))
            textToSpeech?.setSpeechRate(speed.coerceIn(0.7f, 1.5f))

            // Configure language & feminine voice
            val hasHindiScript = text.any { it in '\u0900'..'\u097F' }
            when {
                language == "hi" || hasHindiScript -> {
                    val hiLocale = Locale("hi", "IN")
                    if ((textToSpeech?.isLanguageAvailable(hiLocale) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                        textToSpeech?.language = hiLocale
                        applyFeminineVoice(hiLocale)
                    }
                }
                language == "en" -> {
                    textToSpeech?.language = Locale.US
                    applyFeminineVoice(Locale.US)
                }
                else -> {
                    // Hinglish: Indian English locale with warm feminine tone
                    val inLocale = Locale("en", "IN")
                    if ((textToSpeech?.isLanguageAvailable(inLocale) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                        textToSpeech?.language = inLocale
                        applyFeminineVoice(inLocale)
                    } else {
                        textToSpeech?.language = Locale.ENGLISH
                        applyFeminineVoice(Locale.ENGLISH)
                    }
                }
            }

            val utteranceId = UUID.randomUUID().toString()
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (e: Exception) {
            Log.e(tag, "Error invoking TTS speak", e)
            _isSpeaking.value = false
            onDone?.invoke()
        }
    }

    fun stopSpeaking() {
        try {
            textToSpeech?.stop()
        } catch (e: Exception) {
            Log.e(tag, "Error stopping TTS", e)
        }
        _isSpeaking.value = false
        _statusMessage.value = "SABA IS READY"
    }

    fun setStatus(status: String) {
        _statusMessage.value = status
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (e: Exception) {
            Log.e(tag, "Error during destroy", e)
        }
    }
}
