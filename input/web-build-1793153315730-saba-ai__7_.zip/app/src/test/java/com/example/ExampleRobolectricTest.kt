package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.modular.SabaAction
import com.example.modular.SabaIntentParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SABA AI", appName)
    }

    @Test
    fun `test phone call intent parser`() {
        val action = SabaIntentParser.parse("Call 9876543210")
        assertNotNull(action)
        assertTrue(action is SabaAction.PhoneCall)
        assertEquals("9876543210", (action as SabaAction.PhoneCall).number)
    }

    @Test
    fun `test alarm intent parser`() {
        val action = SabaIntentParser.parse("Alarm lagao 7 baje")
        assertNotNull(action)
        assertTrue(action is SabaAction.SetAlarm)
        assertEquals(7, (action as SabaAction.SetAlarm).hour)
    }

    @Test
    fun `test memory intent parser`() {
        val action = SabaIntentParser.parse("Yaad rakhna favorite food: Biryani")
        assertNotNull(action)
        assertTrue(action is SabaAction.SaveToMemory)
        assertEquals("favorite food", (action as SabaAction.SaveToMemory).key)
        assertEquals("Biryani", (action as SabaAction.SaveToMemory).value)
    }
}
