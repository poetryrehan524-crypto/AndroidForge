package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sessionId: String = "default",
    val sender: String, // "user" or "saba"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isAudio: Boolean = false,
    val isBookmarked: Boolean = false
)
