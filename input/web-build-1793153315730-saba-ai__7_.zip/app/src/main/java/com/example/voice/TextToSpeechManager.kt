package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sin

class TextToSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "TextToSpeechManager"
        private const val UTTERANCE_ID = "saba_speech_utterance"
    }

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _speakingAmplitude = MutableStateFlow(0f)
    val speakingAmplitude: StateFlow<Float> = _speakingAmplitude.asStateFlow()

    private var pulseJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private var currentPitch: Float = 1.05f
    private var currentRate: Float = 1.0f

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupVoice()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                    startSpeechAmplitudePulse()
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    stopSpeechAmplitudePulse()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    stopSpeechAmplitudePulse()
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                    stopSpeechAmplitudePulse()
                    Log.w(TAG, "TTS utterance error: $errorCode")
                }
            })
        } else {
            Log.e(TAG, "Failed to initialize TextToSpeech ($status)")
        }
    }

    fun setSpeechParameters(pitch: Float, rate: Float) {
        currentPitch = pitch
        currentRate = rate
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
    }

    fun setupVoice(languageMode: String = "hinglish") {
        if (!isInitialized || tts == null) return

        tts?.setPitch(currentPitch)
        tts?.setSpeechRate(currentRate)

        // Try to set appropriate Indian English or Hindi locale
        val hindiLocale = Locale("hi", "IN")
        val englishIndiaLocale = Locale("en", "IN")

        val targetLocale = when (languageMode.lowercase(Locale.ROOT)) {
            "hindi" -> hindiLocale
            "english" -> englishIndiaLocale
            else -> {
                // For Hinglish, check if Hindi voice is available, else Indian English, else default
                if (tts?.isLanguageAvailable(hindiLocale) == TextToSpeech.LANG_AVAILABLE) {
                    hindiLocale
                } else if (tts?.isLanguageAvailable(englishIndiaLocale) == TextToSpeech.LANG_AVAILABLE) {
                    englishIndiaLocale
                } else {
                    Locale.getDefault()
                }
            }
        }

        try {
            val result = tts?.setLanguage(targetLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Target locale $targetLocale not supported, using device default")
                tts?.setLanguage(Locale.getDefault())
            }

            // Pick a female voice if available among system voices
            tts?.voices?.find { voice ->
                val name = voice.name.lowercase(Locale.ROOT)
                (voice.locale.language == "hi" || voice.locale.country == "IN") &&
                        (name.contains("female") || name.contains("fem") || name.contains("#female"))
            }?.let { preferredVoice ->
                tts?.voice = preferredVoice
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting TTS voice", e)
        }
    }

    fun speak(text: String, languageMode: String = "hinglish") {
        if (!isInitialized || tts == null) {
            Log.w(TAG, "TTS not initialized yet")
            return
        }

        // Clean text for speech (strip markdown characters, emojis, or formatting)
        val cleanText = text
            .replace(Regex("[*#_`~>\\[\\]()]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (cleanText.isBlank()) return

        stop()
        setupVoice(languageMode)

        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }

    fun stop() {
        try {
            tts?.stop()
            _isSpeaking.value = false
            stopSpeechAmplitudePulse()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping TTS", e)
        }
    }

    private fun startSpeechAmplitudePulse() {
        pulseJob?.cancel()
        pulseJob = scope.launch {
            var phase = 0f
            while (isActive && _isSpeaking.value) {
                // Generate a lively, speech-like organic undulating amplitude (0.3 .. 0.95)
                val base = 0.5f + 0.35f * sin(phase).toFloat()
                val flutter = 0.1f * sin(phase * 2.7f).toFloat()
                _speakingAmplitude.value = (base + flutter).coerceIn(0.2f, 1.0f)
                phase += 0.35f
                delay(50)
            }
            _speakingAmplitude.value = 0f
        }
    }

    private fun stopSpeechAmplitudePulse() {
        pulseJob?.cancel()
        pulseJob = null
        _speakingAmplitude.value = 0f
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
