package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val key: String, // e.g., "User Name", "Diet Preference", "Work", "Favorite Music"
    val value: String, // e.g., "Rahul", "Vegetarian", "Android Engineer", "Arijit Singh"
    val category: String = "General", // "Personal", "Preferences", "Work", "Habits"
    val updatedAt: Long = System.currentTimeMillis()
)
