package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "saba_preferences")

class UserPreferencesRepository(private val context: Context) {

    companion object {
        val KEY_CUSTOM_API_KEY = stringPreferencesKey("custom_api_key")
        val KEY_SELECTED_MODEL = stringPreferencesKey("selected_model")
        val KEY_AUTO_SPEAK = booleanPreferencesKey("auto_speak")
        val KEY_SPEECH_RATE = floatPreferencesKey("speech_rate")
        val KEY_VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val KEY_LANGUAGE_MODE = stringPreferencesKey("language_mode")
        val KEY_WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
    }

    val customApiKey: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_CUSTOM_API_KEY] ?: ""
    }

    val selectedModel: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_SELECTED_MODEL] ?: "gemini-2.5-flash"
    }

    val autoSpeak: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_AUTO_SPEAK] ?: true
    }

    val speechRate: Flow<Float> = context.dataStore.data.map { preferences ->
        preferences[KEY_SPEECH_RATE] ?: 1.0f
    }

    val voicePitch: Flow<Float> = context.dataStore.data.map { preferences ->
        preferences[KEY_VOICE_PITCH] ?: 1.05f
    }

    val languageMode: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_LANGUAGE_MODE] ?: "hinglish"
    }

    val wakeWordEnabled: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_WAKE_WORD_ENABLED] ?: false
    }

    suspend fun setCustomApiKey(key: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_CUSTOM_API_KEY] = key
        }
    }

    suspend fun setSelectedModel(model: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SELECTED_MODEL] = model
        }
    }

    suspend fun setAutoSpeak(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_AUTO_SPEAK] = enabled
        }
    }

    suspend fun setSpeechRate(rate: Float) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SPEECH_RATE] = rate
        }
    }

    suspend fun setVoicePitch(pitch: Float) {
        context.dataStore.edit { preferences ->
            preferences[KEY_VOICE_PITCH] = pitch
        }
    }

    suspend fun setLanguageMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_LANGUAGE_MODE] = mode
        }
    }

    suspend fun setWakeWordEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_WAKE_WORD_ENABLED] = enabled
        }
    }
}
