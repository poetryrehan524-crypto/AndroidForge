package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.SabaViewModel
import com.example.ui.components.SabaNavigationBar
import com.example.ui.components.SabaTab
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MemoryScreen
import com.example.ui.screens.ModularToolsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.SabaAiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SabaAiTheme {
                SabaMainApp()
            }
        }
    }
}

@Composable
fun SabaMainApp(
    viewModel: SabaViewModel = viewModel()
) {
    var currentTab by remember { mutableStateOf(SabaTab.HOME) }

    // System BackHandler: pop back to Home tab if currently on sub-screens
    BackHandler(enabled = currentTab != SabaTab.HOME) {
        currentTab = SabaTab.HOME
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        bottomBar = {
            SabaNavigationBar(
                currentTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        },
        containerColor = ObsidianBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                SabaTab.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToChat = { currentTab = SabaTab.CHAT }
                    )
                }
                SabaTab.CHAT -> {
                    ChatScreen(
                        viewModel = viewModel
                    )
                }
                SabaTab.MEMORY -> {
                    MemoryScreen(
                        viewModel = viewModel
                    )
                }
                SabaTab.MODULES -> {
                    ModularToolsScreen()
                }
                SabaTab.SETTINGS -> {
                    SettingsScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}
