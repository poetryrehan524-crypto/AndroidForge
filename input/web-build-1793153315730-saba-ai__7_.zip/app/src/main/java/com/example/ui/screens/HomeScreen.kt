package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.local.MessageEntity
import com.example.orb.OrbState
import com.example.orb.SabaOrbWithVisualizer
import com.example.ui.SabaViewModel
import com.example.ui.theme.CyanGlowBright
import com.example.ui.theme.CyanGlowPrimary
import com.example.ui.theme.CyanGlowSoft
import com.example.ui.theme.ElectricBlueContainer
import com.example.ui.theme.ElectricBlueSecondary
import com.example.ui.theme.NeonMintDark
import com.example.ui.theme.NeonMintTertiary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSubtle
import com.example.ui.theme.TextWhite

@Composable
fun HomeScreen(
    viewModel: SabaViewModel,
    onNavigateToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val orbAmplitude by viewModel.orbAmplitude.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val memories by viewModel.memories.collectAsState()

    var showTextInput by remember { mutableStateOf(false) }
    var textInput by remember { mutableStateOf("") }

    // Audio recording permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.setMicPermissionGranted(isGranted)
        if (isGranted) {
            viewModel.startVoiceListening()
        }
    }

    LaunchedEffect(Unit) {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        viewModel.setMicPermissionGranted(hasPermission)
    }

    val onMicClicked = {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.toggleVoiceListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val latestSabaMessage = messages.lastOrNull { it.sender == "saba" }

    val quickPrompts = listOf(
        "Namaste Saba!",
        "Tum kya kar sakti ho?",
        "Set alarm for 7:00 AM",
        "Set timer for 5 minutes",
        "WiFi settings kholo",
        "Yaad rakhna mera favorite food Biryani hai"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Top Status Header
        HomeHeader(
            languageMode = uiState.currentLanguage,
            memoryCount = memories.size,
            modelName = uiState.selectedModel
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Centerpiece: Glowing Cyan Orb with live audio reactivity
        SabaOrbWithVisualizer(
            state = uiState.orbState,
            amplitude = orbAmplitude,
            statusLabel = uiState.statusText,
            size = 220.dp,
            onOrbClick = {
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (hasPermission) {
                    viewModel.onOrbClick()
                } else {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Active Action Notice Banner (e.g., Alarm set, WhatsApp triggered)
        AnimatedVisibility(
            visible = !uiState.activeActionNotice.isNullOrBlank(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            uiState.activeActionNotice?.let { notice ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = NeonMintDark),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(listOf(NeonMintTertiary, CyanGlowPrimary))
                    )
                ) {
                    Text(
                        text = "⚡ $notice",
                        color = NeonMintTertiary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }
        }

        // Live Voice Transcription / Current Activity Card
        AnimatedVisibility(
            visible = uiState.partialTranscript.isNotBlank() || uiState.orbState == OrbState.LISTENING
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(CyanGlowPrimary, ElectricBlueSecondary))
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(CyanGlowBright)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (uiState.partialTranscript.isNotBlank()) "Hearing you:" else "Listening for your voice...",
                            color = CyanGlowBright,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (uiState.partialTranscript.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "\"${uiState.partialTranscript}\"",
                            color = TextWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }
            }
        }

        // Latest SABA Response Card (if not listening or thinking)
        if (latestSabaMessage != null && uiState.orbState == OrbState.IDLE) {
            LatestResponseCard(
                message = latestSabaMessage,
                onReplay = { viewModel.speakMessage(latestSabaMessage.content) },
                onViewFullChat = onNavigateToChat
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Suggestion Chips
        Text(
            text = "TRY ASKING SABA",
            color = TextSubtle,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(quickPrompts) { prompt ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ObsidianCard,
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(listOf(ObsidianBorder, ObsidianBorder))
                    ),
                    modifier = Modifier.clickable {
                        viewModel.sendTextMessage(prompt)
                    }
                ) {
                    Text(
                        text = prompt,
                        color = TextWhite,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Text input bar if toggled
        AnimatedVisibility(visible = showTextInput) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Ask SABA in Hinglish...", color = TextMuted) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_text_input"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanGlowPrimary,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        cursorColor = CyanGlowBright
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            viewModel.sendTextMessage(textInput)
                            textInput = ""
                            showTextInput = false
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(CyanGlowPrimary)
                        .testTag("home_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = ObsidianBackground
                    )
                }
            }
        }

        // Bottom Voice & Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Keyboard toggle button
            IconButton(
                onClick = { showTextInput = !showTextInput },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(ObsidianCard)
                    .border(1.dp, ObsidianBorder, CircleShape)
                    .testTag("toggle_keyboard_button")
            ) {
                Icon(
                    imageVector = if (showTextInput) Icons.Default.Close else Icons.Default.Keyboard,
                    contentDescription = "Keyboard input",
                    tint = CyanGlowBright
                )
            }

            // Central Glowing Cyan Mic Button
            val isListening = uiState.orbState == OrbState.LISTENING
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = if (isListening) listOf(NeonMintTertiary, CyanGlowPrimary)
                            else listOf(CyanGlowPrimary, ElectricBlueSecondary)
                        )
                    )
                    .clickable(onClick = onMicClicked)
                    .testTag("mic_button")
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = if (isListening) "Stop Listening" else "Start Voice Input",
                    tint = ObsidianBackground,
                    modifier = Modifier.size(36.dp)
                )
            }

            // Stop speech or Go to full chat button
            IconButton(
                onClick = {
                    if (uiState.orbState == OrbState.SPEAKING) {
                        viewModel.stopSpeaking()
                    } else {
                        onNavigateToChat()
                    }
                },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(ObsidianCard)
                    .border(1.dp, ObsidianBorder, CircleShape)
                    .testTag("stop_or_chat_button")
            ) {
                Icon(
                    imageVector = if (uiState.orbState == OrbState.SPEAKING) Icons.Default.VolumeUp else Icons.Default.Chat,
                    contentDescription = "Chat",
                    tint = if (uiState.orbState == OrbState.SPEAKING) CyanGlowBright else TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun HomeHeader(
    languageMode: String,
    memoryCount: Int,
    modelName: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "SABA AI",
                color = CyanGlowBright,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "AI Voice & Chat Companion",
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // Language Pill
            PillBadge(
                text = languageMode.replaceFirstChar { it.uppercase() },
                color = CyanGlowPrimary
            )
            // Memory Pill
            PillBadge(
                text = "$memoryCount Memories",
                color = NeonMintTertiary
            )
        }
    }
}

@Composable
fun PillBadge(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.12f),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(color.copy(alpha = 0.4f), color.copy(alpha = 0.4f)))
        )
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun LatestResponseCard(
    message: MessageEntity,
    onReplay: () -> Unit,
    onViewFullChat: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(ObsidianBorder, ObsidianBorder))
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(CyanGlowSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("S", color = CyanGlowBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Saba", color = CyanGlowBright, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                Row {
                    IconButton(onClick = onReplay, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speak again",
                            tint = CyanGlowBright,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(onClick = onViewFullChat, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = "View chat",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = message.content,
                color = TextWhite,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }
    }
}
