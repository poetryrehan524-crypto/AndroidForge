package com.example.modular

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log

sealed class SabaAction {
    data class PhoneCall(val number: String, val contactName: String? = null) : SabaAction()
    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : SabaAction()
    data class SetTimer(val durationSeconds: Int, val label: String) : SabaAction()
    data class OpenWhatsApp(val phone: String? = null, val message: String) : SabaAction()
    data class WebSearch(val query: String) : SabaAction()
    data class OpenSystemSetting(val settingType: SettingType) : SabaAction()
    data class SaveToMemory(val key: String, val value: String, val category: String) : SabaAction()
}

enum class SettingType {
    WIFI,
    BLUETOOTH,
    SOUND,
    GENERAL
}

enum class ActionCapabilityStatus {
    ACTIVE_NATIVE,           // Fully working right now via native Android intents
    REQUIRES_PERMISSION,     // Works when runtime permission granted
    PLANNED_EXPANSION        // Modular hook ready; requires additional SDK or system service
}

data class SabaModuleInfo(
    val id: String,
    val title: String,
    val description: String,
    val status: ActionCapabilityStatus,
    val setupRequirement: String,
    val examples: List<String>
)

object SabaActionExecutor {
    private const val TAG = "SabaActionExecutor"

    fun execute(context: Context, action: SabaAction): String {
        return try {
            when (action) {
                is SabaAction.PhoneCall -> {
                    val intent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:${action.number}")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    "Phone dialer open kiya gaya hai ${action.contactName ?: action.number} ke liye."
                }

                is SabaAction.SetAlarm -> {
                    val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_HOUR, action.hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, action.minute)
                        putExtra(AlarmClock.EXTRA_MESSAGE, action.label)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    "Alarm set kiya ja raha hai ${action.hour}:${String.format("%02d", action.minute)} par: '${action.label}'"
                }

                is SabaAction.SetTimer -> {
                    val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                        putExtra(AlarmClock.EXTRA_LENGTH, action.durationSeconds)
                        putExtra(AlarmClock.EXTRA_MESSAGE, action.label)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    "Timer shuru kiya gaya: ${action.durationSeconds} seconds ke liye."
                }

                is SabaAction.OpenWhatsApp -> {
                    val url = if (!action.phone.isNullOrBlank()) {
                        "https://api.whatsapp.com/send?phone=${action.phone}&text=${Uri.encode(action.message)}"
                    } else {
                        "https://api.whatsapp.com/send?text=${Uri.encode(action.message)}"
                    }
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    "WhatsApp open kiya gaya hai message share karne ke liye."
                }

                is SabaAction.WebSearch -> {
                    val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                        putExtra("query", action.query)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    "Web search open kiya gaya: '${action.query}'"
                }

                is SabaAction.OpenSystemSetting -> {
                    val actionName = when (action.settingType) {
                        SettingType.WIFI -> Settings.ACTION_WIFI_SETTINGS
                        SettingType.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
                        SettingType.SOUND -> Settings.ACTION_SOUND_SETTINGS
                        SettingType.GENERAL -> Settings.ACTION_SETTINGS
                    }
                    val intent = Intent(actionName).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    "Device settings open ki gayi hain."
                }

                is SabaAction.SaveToMemory -> {
                    // Handled directly via ViewModel Room repository
                    "Memory me save kiya gaya: ${action.key} -> ${action.value}"
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing action $action", e)
            "Yeh action perform karne me samasya aayi: ${e.message}"
        }
    }
}
