package com.example.data.gemini

import android.util.Log
import com.example.BuildConfig
import com.example.data.local.MemoryEntity
import com.example.data.local.MessageEntity
import java.util.Locale

sealed class GeminiResult {
    data class Success(val responseText: String) : GeminiResult()
    data class Error(val errorMessage: String, val isApiKeyMissing: Boolean = false) : GeminiResult()
}

class GeminiRepository(
    private val apiService: GeminiApiService = GeminiApiService.create()
) {

    companion object {
        private const val TAG = "GeminiRepository"
    }

    suspend fun generateSabaResponse(
        userInput: String,
        conversationHistory: List<MessageEntity>,
        memories: List<MemoryEntity>,
        languageMode: String = "hinglish",
        customApiKey: String = "",
        model: String = "gemini-2.5-flash"
    ): GeminiResult {
        // Resolve effective API key
        val effectiveApiKey = when {
            customApiKey.isNotBlank() -> customApiKey.trim()
            BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY" -> BuildConfig.GEMINI_API_KEY
            else -> ""
        }

        if (effectiveApiKey.isBlank()) {
            Log.w(TAG, "No valid Gemini API key configured. Providing fallback response.")
            return GeminiResult.Success(getFallbackHinglishResponse(userInput, memories))
        }

        try {
            // Build system prompt with SABA persona, memories, and voice-first guidelines
            val memoryContext = if (memories.isNotEmpty()) {
                memories.joinToString("\n") { "- ${it.key}: ${it.value} (${it.category})" }
            } else {
                "No custom memories recorded yet."
            }

            val systemPrompt = """
                You are SABA (Smart Advanced Behavioral Assistant), a friendly, highly intelligent, warm, and perceptive female AI companion inspired by the warmth of Indian conversation.
                
                LANGUAGE & TONE GUIDELINES:
                - Primary style: Natural conversational $languageMode (mix of Hindi & English written in standard Latin alphabet, e.g., 'Haan bilkul, main abhi bata deti hoon!').
                - Voice: Feminine, respectful yet affectionate, empathetic, witty, and like a supportive best friend (dost).
                - Use natural everyday expressions such as 'Haan ji', 'Arre waah!', 'Chaliye', 'Zaroor', 'Fikr mat kijiye', 'Bataiye kya chal raha hai'.
                - Formatting for speech: Keep responses concise, clear, and easy to speak aloud. Avoid heavy markdown like tables or excessive asterisk lists unless explicitly asked.
                
                USER'S STORED MEMORIES & CONTEXT:
                $memoryContext
                
                Always be helpful, honest, and proactive. When the user asks you to remember something, acknowledge warmly.
            """.trimIndent()

            // Build conversation history (up to last 10 turns)
            val historyContents = mutableListOf<GeminiContent>()

            val recentHistory = conversationHistory.takeLast(10)
            for (msg in recentHistory) {
                val role = if (msg.sender == "user") "user" else "model"
                historyContents.add(
                    GeminiContent(
                        role = role,
                        parts = listOf(GeminiPart(text = msg.content))
                    )
                )
            }

            // Append current user message
            historyContents.add(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = userInput))
                )
            )

            val request = GeminiRequest(
                contents = historyContents,
                systemInstruction = GeminiSystemInstruction(
                    parts = listOf(GeminiPart(text = systemPrompt))
                ),
                generationConfig = GeminiGenerationConfig(
                    temperature = 0.75f,
                    maxOutputTokens = 800
                )
            )

            val response = apiService.generateContent(
                model = model,
                apiKey = effectiveApiKey,
                request = request
            )

            if (response.isSuccessful) {
                val candidateText = response.body()?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!candidateText.isNullOrBlank()) {
                    return GeminiResult.Success(candidateText.trim())
                } else {
                    return GeminiResult.Error("Khali response mila. Kripya dobara try kijiye.")
                }
            } else {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                Log.e(TAG, "Gemini API error code: ${response.code()} body: $errorBody")
                return if (response.code() == 400 || response.code() == 403) {
                    GeminiResult.Error("API Key invalid ya unauthorized hai. Settings me jaakar apni Gemini API Key verify kijiye.", isApiKeyMissing = true)
                } else {
                    GeminiResult.Error("API error (${response.code()}): Kripya thodi der baad koshish karein.")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Network or execution error calling Gemini", e)
            // If offline, provide smart local assistant response
            return GeminiResult.Success(getFallbackHinglishResponse(userInput, memories, networkFailed = true))
        }
    }

    private fun getFallbackHinglishResponse(
        query: String,
        memories: List<MemoryEntity>,
        networkFailed: Boolean = false
    ): String {
        val lower = query.lowercase(Locale.ROOT)
        val userName = memories.firstOrNull { it.key.contains("name", ignoreCase = true) }?.value ?: "dost"

        return when {
            lower.contains("kaun ho") || lower.contains("who are you") || lower.contains("tumhara naam") -> {
                "Main hoon SABA (Smart Advanced Behavioral Assistant)! Aapki apni AI dost. Main aapki baaton ka jawab dene, phone actions organise karne aur yaad rakhne ke liye yahan hoon."
            }
            lower.contains("namaste") || lower.contains("hello") || lower.contains("hi") || lower.contains("hey") -> {
                "Namaste $userName! Kaisi hain aap? SABA bilkul taiyyar hai, batayein aaj main aapki kya madad kar sakti hoon?"
            }
            lower.contains("kaise ho") || lower.contains("kaisi ho") || lower.contains("how are you") -> {
                "Main bilkul fit aur badhiya hoon, shukriya! Aap batayein, aapka din kaisa chal raha hai?"
            }
            lower.contains("kya kar sakti") || lower.contains("help") || lower.contains("features") -> {
                "Main aapke saath Hinglish me baatein kar sakti hoon, voice sun sakti hoon aur bol sakti hoon, aapki important baatein memory me yaad rakh sakti hoon, aur Gemini AI se intelligent answers laa sakti hoon!"
            }
            networkFailed -> {
                "Abhi network connection thoda slow lag raha hai, par main aapki baat sun rahi hoon! Thodi der me dobara try kijiye."
            }
            else -> {
                "Maine aapki baat sun li! Full intelligent AI responses ke liye Settings me jaakar apni Gemini API Key daal dijiye, taaki main aur bhi detail me aapko guide kar sakoon."
            }
        }
    }
}
