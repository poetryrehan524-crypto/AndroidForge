package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.gemini.GeminiRepository
import com.example.data.gemini.GeminiResult
import com.example.data.local.MemoryEntity
import com.example.data.local.MessageEntity
import com.example.data.local.SabaDatabase
import com.example.data.local.UserPreferencesRepository
import com.example.modular.SabaAction
import com.example.modular.SabaActionExecutor
import com.example.modular.SabaIntentParser
import com.example.orb.OrbState
import com.example.voice.SpeechRecognitionManager
import com.example.voice.TextToSpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SabaUiState(
    val orbState: OrbState = OrbState.IDLE,
    val statusText: String = "Tap orb or mic to talk to SABA",
    val partialTranscript: String = "",
    val activeActionNotice: String? = null,
    val isMicPermissionGranted: Boolean = false,
    val currentLanguage: String = "hinglish",
    val customApiKey: String = "",
    val selectedModel: String = "gemini-2.5-flash",
    val autoSpeak: Boolean = true,
    val speechRate: Float = 1.0f,
    val voicePitch: Float = 1.05f,
    val wakeWordEnabled: Boolean = false
)

class SabaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SabaDatabase.getDatabase(application)
    private val dao = db.sabaDao()
    private val prefs = UserPreferencesRepository(application)
    private val geminiRepo = GeminiRepository()

    val speechManager = SpeechRecognitionManager(application)
    val ttsManager = TextToSpeechManager(application)

    private val _uiState = MutableStateFlow(SabaUiState())
    val uiState: StateFlow<SabaUiState> = _uiState.asStateFlow()

    val messages: StateFlow<List<MessageEntity>> = dao.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<MemoryEntity>> = dao.getAllMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dynamic amplitude for the Glowing Cyan Orb: combines mic RMS when listening or TTS pulse when speaking
    val orbAmplitude: StateFlow<Float> = combine(
        speechManager.rmsAmplitude,
        ttsManager.speakingAmplitude,
        _uiState
    ) { micRms, ttsRms, state ->
        when (state.orbState) {
            OrbState.LISTENING -> micRms
            OrbState.SPEAKING -> ttsRms
            else -> 0f
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0f)

    init {
        // Collect preferences
        viewModelScope.launch {
            prefs.customApiKey.collect { key ->
                _uiState.value = _uiState.value.copy(customApiKey = key)
            }
        }
        viewModelScope.launch {
            prefs.selectedModel.collect { model ->
                _uiState.value = _uiState.value.copy(selectedModel = model)
            }
        }
        viewModelScope.launch {
            prefs.autoSpeak.collect { auto ->
                _uiState.value = _uiState.value.copy(autoSpeak = auto)
            }
        }
        viewModelScope.launch {
            prefs.speechRate.collect { rate ->
                _uiState.value = _uiState.value.copy(speechRate = rate)
                ttsManager.setSpeechParameters(_uiState.value.voicePitch, rate)
            }
        }
        viewModelScope.launch {
            prefs.voicePitch.collect { pitch ->
                _uiState.value = _uiState.value.copy(voicePitch = pitch)
                ttsManager.setSpeechParameters(pitch, _uiState.value.speechRate)
            }
        }
        viewModelScope.launch {
            prefs.languageMode.collect { mode ->
                _uiState.value = _uiState.value.copy(currentLanguage = mode)
            }
        }
        viewModelScope.launch {
            prefs.wakeWordEnabled.collect { enabled ->
                _uiState.value = _uiState.value.copy(wakeWordEnabled = enabled)
            }
        }

        // Listen for speech recognition transcript updates
        viewModelScope.launch {
            speechManager.partialTranscript.collect { transcript ->
                _uiState.value = _uiState.value.copy(partialTranscript = transcript)
            }
        }

        // Listen for speech final results
        viewModelScope.launch {
            speechManager.finalResult.collect { result ->
                if (result.isNotBlank()) {
                    processUserInput(result, fromVoice = true)
                }
            }
        }

        // Listen for speech errors
        viewModelScope.launch {
            speechManager.errorMessage.collect { err ->
                _uiState.value = _uiState.value.copy(
                    orbState = OrbState.IDLE,
                    statusText = err
                )
            }
        }

        // Synchronize TTS speaking state with Orb state
        viewModelScope.launch {
            ttsManager.isSpeaking.collect { speaking ->
                if (speaking) {
                    _uiState.value = _uiState.value.copy(
                        orbState = OrbState.SPEAKING,
                        statusText = "SABA bol rahi hai..."
                    )
                } else if (_uiState.value.orbState == OrbState.SPEAKING) {
                    _uiState.value = _uiState.value.copy(
                        orbState = OrbState.IDLE,
                        statusText = "SABA taiyyar hai"
                    )
                }
            }
        }
    }

    fun setMicPermissionGranted(granted: Boolean) {
        _uiState.value = _uiState.value.copy(isMicPermissionGranted = granted)
    }

    fun toggleVoiceListening() {
        if (_uiState.value.orbState == OrbState.LISTENING) {
            stopVoiceListening()
        } else {
            startVoiceListening()
        }
    }

    fun startVoiceListening() {
        ttsManager.stop()
        _uiState.value = _uiState.value.copy(
            orbState = OrbState.LISTENING,
            statusText = "Sun rahi hoon... Boliye!",
            partialTranscript = "",
            activeActionNotice = null
        )
        speechManager.startListening(_uiState.value.currentLanguage)
    }

    fun stopVoiceListening() {
        speechManager.stopListening()
        if (_uiState.value.orbState == OrbState.LISTENING) {
            _uiState.value = _uiState.value.copy(
                orbState = OrbState.IDLE,
                statusText = "SABA taiyyar hai"
            )
        }
    }

    fun onOrbClick() {
        when (_uiState.value.orbState) {
            OrbState.SPEAKING -> {
                ttsManager.stop()
                _uiState.value = _uiState.value.copy(
                    orbState = OrbState.IDLE,
                    statusText = "SABA taiyyar hai"
                )
            }
            OrbState.LISTENING -> {
                stopVoiceListening()
            }
            OrbState.THINKING -> {
                // Let it finish or reset
            }
            OrbState.IDLE -> {
                startVoiceListening()
            }
        }
    }

    fun sendTextMessage(text: String) {
        if (text.isBlank()) return
        processUserInput(text.trim(), fromVoice = false)
    }

    private fun processUserInput(input: String, fromVoice: Boolean) {
        viewModelScope.launch {
            // 1. Insert user message to Room DB
            dao.insertMessage(
                MessageEntity(
                    sender = "user",
                    content = input,
                    isAudio = fromVoice
                )
            )

            // Update UI to thinking
            _uiState.value = _uiState.value.copy(
                orbState = OrbState.THINKING,
                statusText = "Soch rahi hoon...",
                partialTranscript = ""
            )

            // 2. Check for modular action intent (Phone call, alarm, timer, WhatsApp, Search, Memory)
            val detectedAction = SabaIntentParser.parse(input)
            var actionResultText: String? = null

            if (detectedAction != null) {
                if (detectedAction is SabaAction.SaveToMemory) {
                    dao.insertMemory(
                        MemoryEntity(
                            key = detectedAction.key,
                            value = detectedAction.value,
                            category = detectedAction.category
                        )
                    )
                    actionResultText = "Bilkul, maine yaad rakh liya hai: '${detectedAction.key}: ${detectedAction.value}'"
                } else {
                    val executionMsg = SabaActionExecutor.execute(getApplication(), detectedAction)
                    _uiState.value = _uiState.value.copy(activeActionNotice = executionMsg)
                    actionResultText = executionMsg
                }
            }

            // 3. Query Gemini AI for intelligent conversation
            val memoryList = dao.getAllMemoriesList()
            val historyList = dao.getRecentMessages(12).reversed()

            val aiResponseText: String = if (actionResultText != null) {
                actionResultText
            } else {
                when (val result = geminiRepo.generateSabaResponse(
                    userInput = input,
                    conversationHistory = historyList,
                    memories = memoryList,
                    languageMode = _uiState.value.currentLanguage,
                    customApiKey = _uiState.value.customApiKey,
                    model = _uiState.value.selectedModel
                )) {
                    is GeminiResult.Success -> result.responseText
                    is GeminiResult.Error -> result.errorMessage
                }
            }

            // 4. Save SABA response to Room DB
            dao.insertMessage(
                MessageEntity(
                    sender = "saba",
                    content = aiResponseText,
                    isAudio = fromVoice
                )
            )

            // 5. Speak response aloud if auto-speak is enabled
            if (_uiState.value.autoSpeak) {
                ttsManager.speak(aiResponseText, _uiState.value.currentLanguage)
            } else {
                _uiState.value = _uiState.value.copy(
                    orbState = OrbState.IDLE,
                    statusText = "SABA taiyyar hai"
                )
            }
        }
    }

    fun speakMessage(text: String) {
        ttsManager.speak(text, _uiState.value.currentLanguage)
    }

    fun stopSpeaking() {
        ttsManager.stop()
    }

    // Memory operations
    fun addMemory(key: String, value: String, category: String = "General") {
        viewModelScope.launch {
            dao.insertMemory(
                MemoryEntity(
                    key = key.trim(),
                    value = value.trim(),
                    category = category.trim()
                )
            )
        }
    }

    fun updateMemory(memory: MemoryEntity) {
        viewModelScope.launch {
            dao.updateMemory(memory)
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch {
            dao.deleteMemory(memory)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            dao.clearAllMemories()
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            dao.clearAllMessages()
            ttsManager.stop()
            _uiState.value = _uiState.value.copy(
                orbState = OrbState.IDLE,
                statusText = "Chat history clear ho gayi hai."
            )
        }
    }

    // Settings actions
    fun setCustomApiKey(key: String) {
        viewModelScope.launch {
            prefs.setCustomApiKey(key.trim())
        }
    }

    fun setSelectedModel(model: String) {
        viewModelScope.launch {
            prefs.setSelectedModel(model)
        }
    }

    fun setAutoSpeak(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setAutoSpeak(enabled)
            if (!enabled) {
                ttsManager.stop()
            }
        }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch {
            prefs.setSpeechRate(rate)
        }
    }

    fun setVoicePitch(pitch: Float) {
        viewModelScope.launch {
            prefs.setVoicePitch(pitch)
        }
    }

    fun setLanguageMode(mode: String) {
        viewModelScope.launch {
            prefs.setLanguageMode(mode)
        }
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setWakeWordEnabled(enabled)
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.destroy()
        ttsManager.shutdown()
    }
}
