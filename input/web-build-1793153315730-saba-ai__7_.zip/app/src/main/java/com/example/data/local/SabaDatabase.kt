package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [MessageEntity::class, MemoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SabaDatabase : RoomDatabase() {
    abstract fun sabaDao(): SabaDao

    companion object {
        @Volatile
        private var INSTANCE: SabaDatabase? = null

        fun getDatabase(context: Context): SabaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SabaDatabase::class.java,
                    "saba_ai_database"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate default starter memories on background thread
                            CoroutineScope(Dispatchers.IO).launch {
                                val dao = getDatabase(context).sabaDao()
                                dao.insertMemory(
                                    MemoryEntity(
                                        key = "Assistant Identity",
                                        value = "Saba, your witty, warm & caring AI companion",
                                        category = "Persona"
                                    )
                                )
                                dao.insertMemory(
                                    MemoryEntity(
                                        key = "Tone & Language",
                                        value = "Fluent Hinglish with friendly Indian warmth and natural humor",
                                        category = "Persona"
                                    )
                                )
                                dao.insertMemory(
                                    MemoryEntity(
                                        key = "Greeting Style",
                                        value = "Namaste & cheerful welcome like a trusted best friend",
                                        category = "Preferences"
                                    )
                                )
                            }
                        }
                    })
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
