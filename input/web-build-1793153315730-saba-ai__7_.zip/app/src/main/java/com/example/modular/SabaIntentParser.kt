package com.example.modular

import java.util.Locale
import java.util.regex.Pattern

object SabaIntentParser {

    fun parse(input: String): SabaAction? {
        val trimmed = input.trim()
        val lower = trimmed.lowercase(Locale.ROOT)

        // 1. Phone Call Intent: "Call 9876543210" or "Phone lagao 9876543210" or "Dial 1234"
        val phoneRegex = Regex("(?:call|phone lagao|dial|call karo)\\s+([0-9+\\- ]{6,15})", RegexOption.IGNORE_CASE)
        val phoneMatch = phoneRegex.find(trimmed)
        if (phoneMatch != null) {
            val number = phoneMatch.groupValues[1].replace(" ", "").replace("-", "")
            return SabaAction.PhoneCall(number = number)
        }

        // 2. Alarm Intent: "Set alarm for 7:30" or "Alarm lagao 6 baje" or "Alarm set karo 7 30"
        val alarmRegex = Regex("(?:set alarm|alarm lagao|alarm set karo)(?:\\s+for)?\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje)?", RegexOption.IGNORE_CASE)
        val alarmMatch = alarmRegex.find(lower)
        if (alarmMatch != null) {
            var hour = alarmMatch.groupValues[1].toIntOrNull() ?: 7
            val minute = alarmMatch.groupValues[2].toIntOrNull() ?: 0
            val amPm = alarmMatch.groupValues[3]

            if (amPm == "pm" && hour < 12) hour += 12
            if (amPm == "am" && hour == 12) hour = 0

            return SabaAction.SetAlarm(hour = hour, minute = minute, label = "SABA Alarm")
        }

        // 3. Timer Intent: "Set timer for 5 minutes" or "Timer lagao 2 minute" or "Timer 30 seconds"
        val timerRegex = Regex("(?:set timer|timer lagao|timer set karo)(?:\\s+for)?\\s+(\\d+)\\s*(minute|min|second|sec|ghanta|hour)?", RegexOption.IGNORE_CASE)
        val timerMatch = timerRegex.find(lower)
        if (timerMatch != null) {
            val count = timerMatch.groupValues[1].toIntOrNull() ?: 1
            val unit = timerMatch.groupValues[2]
            val durationSeconds = when {
                unit.contains("sec") -> count
                unit.contains("hour") || unit.contains("ghanta") -> count * 3600
                else -> count * 60 // default minutes
            }
            return SabaAction.SetTimer(durationSeconds = durationSeconds, label = "SABA Timer")
        }

        // 4. WhatsApp Intent: "WhatsApp karo [message]" or "Send WhatsApp [message]"
        val waRegex = Regex("(?:whatsapp karo|send whatsapp|whatsapp message|whatsapp pe bhejo)\\s+(.+)", RegexOption.IGNORE_CASE)
        val waMatch = waRegex.find(trimmed)
        if (waMatch != null) {
            val msg = waMatch.groupValues[1].trim()
            return SabaAction.OpenWhatsApp(message = msg)
        }

        // 5. Web Search Intent: "Search on google [query]" or "Search web [query]" or "Google search [query]"
        val searchRegex = Regex("(?:search on google|google search|search web|search karo|google karo)\\s+(.+)", RegexOption.IGNORE_CASE)
        val searchMatch = searchRegex.find(trimmed)
        if (searchMatch != null) {
            val query = searchMatch.groupValues[1].trim()
            return SabaAction.WebSearch(query = query)
        }

        // 6. Settings Intent: "Open wifi settings", "Open bluetooth", "Device settings"
        if (lower.contains("wifi") && (lower.contains("setting") || lower.contains("kholo") || lower.contains("open"))) {
            return SabaAction.OpenSystemSetting(SettingType.WIFI)
        }
        if (lower.contains("bluetooth") && (lower.contains("setting") || lower.contains("kholo") || lower.contains("open"))) {
            return SabaAction.OpenSystemSetting(SettingType.BLUETOOTH)
        }
        if (lower.contains("sound") && (lower.contains("setting") || lower.contains("kholo") || lower.contains("open"))) {
            return SabaAction.OpenSystemSetting(SettingType.SOUND)
        }
        if (lower == "settings kholo" || lower == "open settings") {
            return SabaAction.OpenSystemSetting(SettingType.GENERAL)
        }

        // 7. Remember / Memory Intent: "Yaad rakhna mera favourite color blue hai" or "Remember that my name is Priya"
        val memoryRegex = Regex("(?:yaad rakhna|remember that|note down|save to memory)\\s+(.+)", RegexOption.IGNORE_CASE)
        val memoryMatch = memoryRegex.find(trimmed)
        if (memoryMatch != null) {
            val fact = memoryMatch.groupValues[1].trim()
            val colonSplit = fact.split(":", limit = 2)
            val key = if (colonSplit.size > 1) colonSplit[0].trim() else "User Note"
            val value = if (colonSplit.size > 1) colonSplit[1].trim() else fact
            return SabaAction.SaveToMemory(key = key, value = value, category = "Saved Fact")
        }

        return null
    }
}
