package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SabaDarkColorScheme = darkColorScheme(
    primary = CyanGlowPrimary,
    onPrimary = ObsidianBackground,
    primaryContainer = CyanGlowSoft,
    onPrimaryContainer = CyanGlowBright,
    secondary = ElectricBlueSecondary,
    onSecondary = ObsidianBackground,
    secondaryContainer = ElectricBlueContainer,
    onSecondaryContainer = CyanGlowBright,
    tertiary = NeonMintTertiary,
    onTertiary = ObsidianBackground,
    tertiaryContainer = NeonMintDark,
    onTertiaryContainer = NeonMintTertiary,
    background = ObsidianBackground,
    onBackground = TextWhite,
    surface = ObsidianSurface,
    onSurface = TextWhite,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = TextMuted,
    outline = ObsidianBorder,
    outlineVariant = Color(0xFF1B2C47),
    error = NeonRedError,
    onError = Color.White
)

@Composable
fun SabaAiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SabaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
