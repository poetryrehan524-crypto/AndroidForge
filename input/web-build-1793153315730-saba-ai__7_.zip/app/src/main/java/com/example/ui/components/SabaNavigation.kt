package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanGlowBright
import com.example.ui.theme.CyanGlowPrimary
import com.example.ui.theme.CyanGlowSoft
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted

enum class SabaTab(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    HOME("home", "SABA", Icons.Default.Mic),
    CHAT("chat", "Chat", Icons.Default.Chat),
    MEMORY("memory", "Memory", Icons.Default.Psychology),
    MODULES("modules", "Actions", Icons.Default.Extension),
    SETTINGS("settings", "Settings", Icons.Default.Settings)
}

@Composable
fun SabaNavigationBar(
    currentTab: SabaTab,
    onTabSelected: (SabaTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .background(ObsidianSurface)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("saba_bottom_nav"),
        containerColor = ObsidianSurface,
        tonalElevation = 6.dp
    ) {
        SabaTab.values().forEach { tab ->
            val isSelected = currentTab == tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.title,
                        tint = if (isSelected) CyanGlowBright else TextMuted
                    )
                },
                label = {
                    Text(
                        text = tab.title,
                        color = if (isSelected) CyanGlowBright else TextMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = CyanGlowSoft,
                    selectedIconColor = CyanGlowBright,
                    selectedTextColor = CyanGlowBright,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                ),
                modifier = Modifier.testTag("nav_item_${tab.route}")
            )
        }
    }
}
