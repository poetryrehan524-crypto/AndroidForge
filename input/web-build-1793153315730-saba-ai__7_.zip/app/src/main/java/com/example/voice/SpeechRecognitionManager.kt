package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class SpeechRecognitionManager(private val context: Context) : RecognitionListener {

    companion object {
        private const val TAG = "SpeechRecognition"
    }

    private var speechRecognizer: SpeechRecognizer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _rmsAmplitude = MutableStateFlow(0f)
    val rmsAmplitude: StateFlow<Float> = _rmsAmplitude.asStateFlow()

    private val _finalResult = MutableSharedFlow<String>()
    val finalResult: SharedFlow<String> = _finalResult.asSharedFlow()

    private val _errorMessage = MutableSharedFlow<String>()
    val errorMessage: SharedFlow<String> = _errorMessage.asSharedFlow()

    init {
        initializeRecognizer()
    }

    private fun initializeRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@SpeechRecognitionManager)
            }
        } else {
            Log.w(TAG, "Speech recognition is not available on this device")
        }
    }

    fun startListening(languageMode: String = "hinglish") {
        if (speechRecognizer == null) {
            initializeRecognizer()
        }

        if (speechRecognizer == null) {
            _errorMessage.tryEmit("Speech recognizer available nahi hai device par.")
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

            val locale = when (languageMode.lowercase(Locale.ROOT)) {
                "hindi" -> "hi-IN"
                "english" -> "en-IN"
                else -> "hi-IN" // Hinglish recognizes Hindi and English well with Indian accent
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale)
        }

        try {
            _partialTranscript.value = ""
            _rmsAmplitude.value = 0f
            speechRecognizer?.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Error starting speech recognition", e)
            _isListening.value = false
            _errorMessage.tryEmit("Mic start karne me samasya aayi: ${e.message}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            _isListening.value = false
            _rmsAmplitude.value = 0f
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recognizer", e)
        }
    }

    fun cancel() {
        try {
            speechRecognizer?.cancel()
            _isListening.value = false
            _rmsAmplitude.value = 0f
            _partialTranscript.value = ""
        } catch (e: Exception) {
            Log.e(TAG, "Error canceling recognizer", e)
        }
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying recognizer", e)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {
        _isListening.value = true
    }

    override fun onBeginningOfSpeech() {
        _isListening.value = true
    }

    override fun onRmsChanged(rmsdB: Float) {
        // rmsdB typically ranges from -2 to 10 dB
        // Normalize to 0.0f .. 1.0f for visualizer orb
        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        _rmsAmplitude.value = normalized
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        _isListening.value = false
        _rmsAmplitude.value = 0f
    }

    override fun onError(error: Int) {
        _isListening.value = false
        _rmsAmplitude.value = 0f
        val msg = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_CLIENT -> "Client side error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission nahi mili"
            SpeechRecognizer.ERROR_NETWORK -> "Network issue"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
            SpeechRecognizer.ERROR_NO_MATCH -> "Aawaz samajh nahi aayi, dobara boliye"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai"
            SpeechRecognizer.ERROR_SERVER -> "Server error"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch sunai nahi diya"
            else -> "Speech recognition error ($error)"
        }
        Log.w(TAG, "Speech recognition error: $msg ($error)")
        // Don't spam no-match if silent
        if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            _errorMessage.tryEmit(msg)
        }
    }

    override fun onResults(results: Bundle?) {
        _isListening.value = false
        _rmsAmplitude.value = 0f
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull()?.trim()
        if (!text.isNullOrBlank()) {
            _partialTranscript.value = text
            _finalResult.tryEmit(text)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull()?.trim()
        if (!text.isNullOrBlank()) {
            _partialTranscript.value = text
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}
}
