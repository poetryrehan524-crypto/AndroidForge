package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.ui.SabaViewModel
import com.example.ui.theme.CyanGlowBright
import com.example.ui.theme.CyanGlowPrimary
import com.example.ui.theme.CyanGlowSoft
import com.example.ui.theme.ElectricBlueContainer
import com.example.ui.theme.NeonAmberWarning
import com.example.ui.theme.NeonGreenSuccess
import com.example.ui.theme.NeonMintTertiary
import com.example.ui.theme.NeonRedError
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSubtle
import com.example.ui.theme.TextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SabaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()

    var apiKeyInput by remember(uiState.customApiKey) { mutableStateOf(uiState.customApiKey) }
    var isApiKeyVisible by remember { mutableStateOf(false) }

    val hasBuildConfigKey = BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = ObsidianBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings & AI Config",
                        color = CyanGlowBright,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianSurface)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // 1. GEMINI API KEY SECTION
            SettingsSectionHeader(title = "GEMINI API CONFIGURATION", icon = Icons.Default.Key)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(ObsidianBorder, ObsidianBorder))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Gemini API Key",
                            color = TextWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        // Status badge
                        val isConfigured = uiState.customApiKey.isNotBlank() || hasBuildConfigKey
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isConfigured) NeonGreenSuccess.copy(alpha = 0.15f) else NeonAmberWarning.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (isConfigured) "Active" else "Key Required",
                                color = if (isConfigured) NeonGreenSuccess else NeonAmberWarning,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (hasBuildConfigKey) {
                            "Environment key detected from Secrets panel (BuildConfig). You can also override it with a custom key below."
                        } else {
                            "Enter your Google Gemini API key to enable intelligent reasoning. You can also configure it in the AI Studio Secrets panel."
                        },
                        color = TextMuted,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        placeholder = { Text("AIzaSy...", color = TextMuted) },
                        visualTransformation = if (isApiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isApiKeyVisible = !isApiKeyVisible }) {
                                Icon(
                                    imageVector = if (isApiKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Visibility",
                                    tint = TextMuted
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_key_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanGlowPrimary,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        if (uiState.customApiKey.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    apiKeyInput = ""
                                    viewModel.setCustomApiKey("")
                                    Toast.makeText(context, "Custom API key removed", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.padding(end = 8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonRedError)
                            ) {
                                Text("Clear")
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.setCustomApiKey(apiKeyInput)
                                Toast.makeText(context, "API Key saved successfully", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanGlowPrimary,
                                contentColor = ObsidianBackground
                            ),
                            modifier = Modifier.testTag("save_api_key_button")
                        ) {
                            Text("Save Key", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = TextSubtle,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Keys stored on device only. Do not share public APK builds.",
                            color = TextSubtle,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // 2. AI MODEL SELECTION
            SettingsSectionHeader(title = "AI INTELLIGENCE MODEL", icon = Icons.Default.Tune)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(ObsidianBorder, ObsidianBorder))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val models = listOf(
                        "gemini-2.5-flash" to "Fastest & Ultra-Smart (Recommended)",
                        "gemini-1.5-flash" to "Standard Balanced",
                        "gemini-2.0-flash" to "Next-Gen Low Latency"
                    )

                    models.forEach { (modelId, desc) ->
                        val isSelected = uiState.selectedModel == modelId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) CyanGlowSoft else Color.Transparent)
                                .border(
                                    1.dp,
                                    if (isSelected) CyanGlowPrimary.copy(alpha = 0.5f) else Color.Transparent,
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = modelId,
                                    color = if (isSelected) CyanGlowBright else TextWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = desc,
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }

                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setSelectedModel(modelId) },
                                label = { Text(if (isSelected) "Active" else "Select") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanGlowPrimary,
                                    selectedLabelColor = ObsidianBackground
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }

            // 3. VOICE & SPEECH SETTINGS
            SettingsSectionHeader(title = "VOICE & CONVERSATION", icon = Icons.Default.RecordVoiceOver)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(ObsidianBorder, ObsidianBorder))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Auto Speak Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto-Speak Responses",
                                color = TextWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Read responses aloud with friendly female voice",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }

                        Switch(
                            checked = uiState.autoSpeak,
                            onCheckedChange = { viewModel.setAutoSpeak(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyanGlowBright,
                                checkedTrackColor = CyanGlowSoft
                            ),
                            modifier = Modifier.testTag("auto_speak_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Language Preference
                    Text(
                        text = "Conversation Style",
                        color = TextWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("hinglish" to "Hinglish", "hindi" to "Hindi", "english" to "English").forEach { (code, label) ->
                            val isSelected = uiState.currentLanguage == code
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setLanguageMode(code) },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanGlowPrimary,
                                    selectedLabelColor = ObsidianBackground,
                                    containerColor = ObsidianSurface,
                                    labelColor = TextWhite
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Voice Pitch Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Voice Pitch", color = TextWhite, fontSize = 13.sp)
                        Text("${String.format("%.2f", uiState.voicePitch)}x", color = CyanGlowBright, fontSize = 13.sp)
                    }
                    Slider(
                        value = uiState.voicePitch,
                        onValueChange = { viewModel.setVoicePitch(it) },
                        valueRange = 0.8f..1.4f,
                        colors = SliderDefaults.colors(
                            thumbColor = CyanGlowBright,
                            activeTrackColor = CyanGlowPrimary,
                            inactiveTrackColor = ObsidianBorder
                        )
                    )

                    // Speech Rate Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Speech Rate", color = TextWhite, fontSize = 13.sp)
                        Text("${String.format("%.2f", uiState.speechRate)}x", color = CyanGlowBright, fontSize = 13.sp)
                    }
                    Slider(
                        value = uiState.speechRate,
                        onValueChange = { viewModel.setSpeechRate(it) },
                        valueRange = 0.7f..1.4f,
                        colors = SliderDefaults.colors(
                            thumbColor = CyanGlowBright,
                            activeTrackColor = CyanGlowPrimary,
                            inactiveTrackColor = ObsidianBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedButton(
                        onClick = {
                            viewModel.speakMessage("Namaste! Main hoon Saba, aapki AI dost. Voice settings test ho rahi hain.")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Test Voice Sample", color = CyanGlowBright)
                    }
                }
            }

            // 4. WAKE PHRASE ("Hey Saba")
            SettingsSectionHeader(title = "HANDS-FREE WAKE WORD", icon = Icons.Default.Info)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(ObsidianBorder, ObsidianBorder))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Wake Phrase: 'Hey Saba'",
                                    color = TextWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = ElectricBlueContainer
                                ) {
                                    Text(
                                        text = "Architecture Hook",
                                        color = CyanGlowBright,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Continuous on-device hotword listener (Picovoice Porcupine / Vosk integration)",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }

                        Switch(
                            checked = uiState.wakeWordEnabled,
                            onCheckedChange = { viewModel.setWakeWordEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyanGlowBright,
                                checkedTrackColor = CyanGlowSoft
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "To enable hands-free activation from the background, integrate an on-device wake-word neural model file (.ppn). The modular service architecture is configured and ready.",
                        color = TextSubtle,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }

            // 5. SYSTEM DIAGNOSTICS
            SettingsSectionHeader(title = "SYSTEM DIAGNOSTICS", icon = Icons.Default.CheckCircle)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiagnosticRow(label = "Microphone Permission", status = if (uiState.isMicPermissionGranted) "Granted" else "Requires Runtime Prompt", isOk = uiState.isMicPermissionGranted)
                    DiagnosticRow(label = "Speech Recognizer", status = "Native Android Recognizer Ready", isOk = true)
                    DiagnosticRow(label = "Text-to-Speech Engine", status = "Android System TTS Active", isOk = true)
                    DiagnosticRow(label = "Local Persistence", status = "Room Database Active (SQLite)", isOk = true)
                    DiagnosticRow(label = "Gemini Connectivity", status = if (uiState.customApiKey.isNotBlank() || hasBuildConfigKey) "Key Present" else "Offline Fallback Mode", isOk = uiState.customApiKey.isNotBlank() || hasBuildConfigKey)
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = CyanGlowPrimary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            color = CyanGlowPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp
        )
    }
}

@Composable
fun DiagnosticRow(label: String, status: String, isOk: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextWhite, fontSize = 12.sp)
        Text(
            text = status,
            color = if (isOk) NeonGreenSuccess else NeonAmberWarning,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
