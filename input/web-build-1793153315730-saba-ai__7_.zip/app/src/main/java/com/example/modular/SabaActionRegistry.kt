package com.example.modular

object SabaActionRegistry {

    val modules: List<SabaModuleInfo> = listOf(
        SabaModuleInfo(
            id = "phone_automation",
            title = "Phone & Clock Automation",
            description = "Direct phone dialer, setting alarms, timers, and toggling system settings.",
            status = ActionCapabilityStatus.ACTIVE_NATIVE,
            setupRequirement = "Active via standard Android Intents. No root or dangerous permissions needed.",
            examples = listOf(
                "Call 9876543210",
                "Set alarm for 6:30 AM",
                "Start 10 minute timer",
                "Open WiFi settings"
            )
        ),
        SabaModuleInfo(
            id = "whatsapp_actions",
            title = "WhatsApp Quick Share",
            description = "Pre-fill WhatsApp messages and open chats directly from voice commands.",
            status = ActionCapabilityStatus.ACTIVE_NATIVE,
            setupRequirement = "Active via WhatsApp Universal URI intent. Requires WhatsApp installed on device.",
            examples = listOf(
                "WhatsApp karo 'Main 10 minute me pahunch rahi hoon'",
                "Send WhatsApp to 919876543210"
            )
        ),
        SabaModuleInfo(
            id = "internet_search",
            title = "Web & Search Integration",
            description = "Instant Google/Web searches triggered through voice or chat.",
            status = ActionCapabilityStatus.ACTIVE_NATIVE,
            setupRequirement = "Active via Android Web Search intent. Opens default browser.",
            examples = listOf(
                "Search on web latest tech news",
                "Google search biryani recipe"
            )
        ),
        SabaModuleInfo(
            id = "memory_vault",
            title = "User Memory & Context",
            description = "Persistent Room DB storage for user preferences, routines, names, and habits.",
            status = ActionCapabilityStatus.ACTIVE_NATIVE,
            setupRequirement = "Fully active on-device via Room SQLite database.",
            examples = listOf(
                "Remember that my favorite food is Dal Makhani",
                "Yaad rakhna meri meeting 4 baje hai"
            )
        ),
        SabaModuleInfo(
            id = "wake_phrase",
            title = "Custom Wake Phrase ('Hey Saba')",
            description = "Always-on hotword detection to wake up SABA hands-free.",
            status = ActionCapabilityStatus.PLANNED_EXPANSION,
            setupRequirement = "Requires a low-power on-device Porcupine/Vosk wake-word neural engine and foreground service audio permission.",
            examples = listOf(
                "Say 'Hey Saba' to wake up anytime (Configurable in Settings)"
            )
        ),
        SabaModuleInfo(
            id = "camera_vision",
            title = "Camera & Vision Understanding",
            description = "Capture surroundings and query Gemini Multimodal Vision API.",
            status = ActionCapabilityStatus.REQUIRES_PERMISSION,
            setupRequirement = "Requires CameraX runtime permission and Gemini Multimodal upload pipeline.",
            examples = listOf(
                "Take a picture and ask what is in front of me"
            )
        ),
        SabaModuleInfo(
            id = "screen_understanding",
            title = "Screen Understanding & OCR",
            description = "Analyze the currently active screen content to assist with forms or reading.",
            status = ActionCapabilityStatus.PLANNED_EXPANSION,
            setupRequirement = "Requires Android AccessibilityService or MediaProjection capture permission with user consent.",
            examples = listOf(
                "Read what is on my screen"
            )
        )
    )
}
