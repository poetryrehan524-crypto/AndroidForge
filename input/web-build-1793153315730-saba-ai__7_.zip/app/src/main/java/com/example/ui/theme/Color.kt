package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Deep Dark Base
val ObsidianBackground = Color(0xFF090D16)
val ObsidianSurface = Color(0xFF0E1626)
val ObsidianSurfaceVariant = Color(0xFF142036)
val ObsidianCard = Color(0xFF111C2E)
val ObsidianBorder = Color(0xFF1F324D)

// Glowing Cyan & Electric Accents
val CyanGlowPrimary = Color(0xFF00E5FF)
val CyanGlowBright = Color(0xFF5DF2FF)
val CyanGlowDark = Color(0xFF007A8A)
val CyanGlowSoft = Color(0xFF002F38)

val ElectricBlueSecondary = Color(0xFF00B0FF)
val ElectricBlueContainer = Color(0xFF0A2E50)

val NeonMintTertiary = Color(0xFF00FFCC)
val NeonMintDark = Color(0xFF003D31)

// Status & Indicators
val NeonRedError = Color(0xFFFF5252)
val NeonGreenSuccess = Color(0xFF00E676)
val NeonAmberWarning = Color(0xFFFFD700)

// Text Colors
val TextWhite = Color(0xFFF1F5F9)
val TextMuted = Color(0xFF94A3B8)
val TextSubtle = Color(0xFF64748B)
val TextCyanAccent = Color(0xFF80F0FF)
