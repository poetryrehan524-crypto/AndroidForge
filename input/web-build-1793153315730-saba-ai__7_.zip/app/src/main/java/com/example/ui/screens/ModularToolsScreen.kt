package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.ScreenSearchDesktop
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.modular.ActionCapabilityStatus
import com.example.modular.SabaAction
import com.example.modular.SabaActionExecutor
import com.example.modular.SabaActionRegistry
import com.example.modular.SabaModuleInfo
import com.example.modular.SettingType
import com.example.ui.theme.CyanGlowBright
import com.example.ui.theme.CyanGlowPrimary
import com.example.ui.theme.CyanGlowSoft
import com.example.ui.theme.ElectricBlueContainer
import com.example.ui.theme.ElectricBlueSecondary
import com.example.ui.theme.NeonAmberWarning
import com.example.ui.theme.NeonGreenSuccess
import com.example.ui.theme.NeonMintTertiary
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSubtle
import com.example.ui.theme.TextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModularToolsScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val modules = SabaActionRegistry.modules

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = ObsidianBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Modular Action Architecture",
                            color = CyanGlowBright,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Extensible tools & system automation capabilities",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianSurface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(6.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(listOf(CyanGlowSoft, ObsidianBorder))
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Modular Architecture Overview",
                            color = CyanGlowBright,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "SABA is architected with modular capability plugins. Core native automations (Phone, Alarms, WhatsApp, Web, Memory) are completely functional now. Advanced system services (wake word, vision, screen OCR) have clean hooks and clearly specify required setup.",
                            color = TextMuted,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            items(modules, key = { it.id }) { module ->
                ModuleCard(module = module, context = context)
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
fun ModuleCard(
    module: SabaModuleInfo,
    context: Context
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("module_card_${module.id}"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(ObsidianBorder, ObsidianBorder))
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val icon = when (module.id) {
                        "phone_automation" -> Icons.Default.Call
                        "whatsapp_actions" -> Icons.Default.Send
                        "internet_search" -> Icons.Default.Search
                        "memory_vault" -> Icons.Default.Psychology
                        "wake_phrase" -> Icons.Default.Hearing
                        "camera_vision" -> Icons.Default.CameraAlt
                        "screen_understanding" -> Icons.Default.ScreenSearchDesktop
                        else -> Icons.Default.Extension
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CyanGlowSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = CyanGlowBright,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = module.title,
                        color = TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Status pill
                val (statusText, statusColor) = when (module.status) {
                    ActionCapabilityStatus.ACTIVE_NATIVE -> "Active (Native)" to NeonGreenSuccess
                    ActionCapabilityStatus.REQUIRES_PERMISSION -> "Needs Permission" to NeonAmberWarning
                    ActionCapabilityStatus.PLANNED_EXPANSION -> "Hook Ready" to ElectricBlueSecondary
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = statusText,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = module.description,
                color = TextMuted,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Setup Requirement Box
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = ObsidianSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "INTEGRATION STATUS / SETUP REQUIREMENT:",
                        color = TextSubtle,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = module.setupRequirement,
                        color = TextWhite,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sample voice commands
            Text(
                text = "Voice Command Examples:",
                color = CyanGlowPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            module.examples.forEach { example ->
                Text(
                    text = "• \"$example\"",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            // Quick native test buttons for ACTIVE_NATIVE modules
            if (module.id == "phone_automation") {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            SabaActionExecutor.execute(context, SabaAction.PhoneCall("100"))
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Open Dialer", fontSize = 11.sp, color = CyanGlowBright)
                    }
                    OutlinedButton(
                        onClick = {
                            SabaActionExecutor.execute(context, SabaAction.OpenSystemSetting(SettingType.WIFI))
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("WiFi Settings", fontSize = 11.sp, color = CyanGlowBright)
                    }
                }
            } else if (module.id == "internet_search") {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        SabaActionExecutor.execute(context, SabaAction.WebSearch("SABA AI assistant"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Test Web Search Intent", fontSize = 11.sp, color = CyanGlowBright)
                }
            } else if (module.id == "whatsapp_actions") {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        SabaActionExecutor.execute(context, SabaAction.OpenWhatsApp(message = "Hello from SABA AI!"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Test WhatsApp Share", fontSize = 11.sp, color = CyanGlowBright)
                }
            }
        }
    }
}
