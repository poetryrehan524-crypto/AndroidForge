package com.example.orb

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanGlowBright
import com.example.ui.theme.CyanGlowPrimary
import com.example.ui.theme.ElectricBlueSecondary
import com.example.ui.theme.NeonMintTertiary
import com.example.ui.theme.TextMuted
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class OrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

@Composable
fun SabaOrb(
    state: OrbState,
    amplitude: Float, // 0.0f .. 1.0f
    modifier: Modifier = Modifier,
    orbSize: Dp = 240.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_infinite")

    // Continuous rotation for orbit particles & thinking vortex
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (state == OrbState.THINKING) 2200 else 9000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_rotation"
    )

    // Breathing pulse for idle & speaking
    val idleBreath by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_idle_breath"
    )

    // Smooth animated amplitude value
    val smoothAmplitude = remember { Animatable(0f) }
    LaunchedEffect(amplitude) {
        smoothAmplitude.animateTo(
            targetValue = amplitude.coerceIn(0f, 1f),
            animationSpec = tween(durationMillis = 80, easing = LinearEasing)
        )
    }

    Box(
        modifier = modifier
            .size(orbSize)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag("saba_orb"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = this.size.width
            val canvasH = this.size.height
            val center = Offset(canvasW / 2f, canvasH / 2f)
            val baseRadius = (canvasW.coerceAtMost(canvasH) / 2f) * 0.42f

            // Dynamic scale multiplier based on state & audio reactivity
            val dynamicScale = when (state) {
                OrbState.IDLE -> idleBreath
                OrbState.LISTENING -> 1.0f + (smoothAmplitude.value * 0.38f)
                OrbState.SPEAKING -> 1.0f + (smoothAmplitude.value * 0.42f)
                OrbState.THINKING -> 1.08f + (sin(rotation * PI.toFloat() / 90f) * 0.05f)
            }

            val currentCoreRadius = baseRadius * dynamicScale

            // 1. Far outer diffuse aura glow
            val outerAuraColor = when (state) {
                OrbState.LISTENING -> NeonMintTertiary.copy(alpha = 0.28f)
                OrbState.SPEAKING -> ElectricBlueSecondary.copy(alpha = 0.32f)
                OrbState.THINKING -> CyanGlowBright.copy(alpha = 0.25f)
                OrbState.IDLE -> CyanGlowPrimary.copy(alpha = 0.16f)
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        outerAuraColor,
                        outerAuraColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = currentCoreRadius * 2.1f
                ),
                radius = currentCoreRadius * 2.1f,
                center = center
            )

            // 2. Concentric animated orbit wave rings
            val ringCount = if (state == OrbState.LISTENING || state == OrbState.SPEAKING) 3 else 2
            for (i in 1..ringCount) {
                val ringOffsetRadius = currentCoreRadius * (1.18f + (i * 0.22f))
                val ringAlpha = when (state) {
                    OrbState.LISTENING -> (0.55f - (i * 0.15f)) * (0.4f + (smoothAmplitude.value * 0.6f))
                    OrbState.SPEAKING -> (0.6f - (i * 0.15f)) * (0.4f + (smoothAmplitude.value * 0.6f))
                    OrbState.THINKING -> 0.45f - (i * 0.12f)
                    OrbState.IDLE -> (0.28f - (i * 0.1f))
                }.coerceIn(0.05f, 0.9f)

                val ringColor = if (i % 2 == 0) NeonMintTertiary else CyanGlowPrimary

                drawCircle(
                    color = ringColor.copy(alpha = ringAlpha),
                    radius = ringOffsetRadius,
                    center = center,
                    style = Stroke(
                        width = if (state == OrbState.LISTENING) 2.5.dp.toPx() else 1.8.dp.toPx()
                    )
                )

                // Swirling orbital energy arcs on the rings
                val arcSweep = if (state == OrbState.THINKING) 85f else 55f
                val arcStart = (rotation * (if (i % 2 == 0) -1.2f else 1.0f) + (i * 70f)) % 360f

                drawArc(
                    color = if (i % 2 == 0) ElectricBlueSecondary else CyanGlowBright,
                    startAngle = arcStart,
                    sweepAngle = arcSweep,
                    useCenter = false,
                    topLeft = Offset(center.x - ringOffsetRadius, center.y - ringOffsetRadius),
                    size = androidx.compose.ui.geometry.Size(ringOffsetRadius * 2f, ringOffsetRadius * 2f),
                    style = Stroke(
                        width = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                )
            }

            // 3. Orbiting particles/energy nodes
            val particleCount = if (state == OrbState.THINKING) 8 else 5
            for (p in 0 until particleCount) {
                val angleRad = (rotation * (if (p % 2 == 0) 1f else -1f) + (p * (360f / particleCount))) * (PI.toFloat() / 180f)
                val orbitDist = currentCoreRadius * (1.25f + (sin(rotation * 0.05f + p) * 0.15f))
                val pX = center.x + cos(angleRad) * orbitDist
                val pY = center.y + sin(angleRad) * orbitDist

                val particleColor = when (p % 3) {
                    0 -> CyanGlowBright
                    1 -> NeonMintTertiary
                    else -> ElectricBlueSecondary
                }

                drawCircle(
                    color = particleColor.copy(alpha = 0.85f),
                    radius = 3.5.dp.toPx(),
                    center = Offset(pX, pY)
                )
            }

            // 4. Main Glowing Sphere Core (Layered multi-stop radial gradient)
            val coreColors = when (state) {
                OrbState.LISTENING -> listOf(
                    Color(0xFFE0FFFF),
                    NeonMintTertiary,
                    CyanGlowPrimary,
                    Color(0xFF005461),
                    Color(0xFF061824)
                )
                OrbState.SPEAKING -> listOf(
                    Color(0xFFFFFFFF),
                    CyanGlowBright,
                    ElectricBlueSecondary,
                    Color(0xFF003D66),
                    Color(0xFF081426)
                )
                OrbState.THINKING -> listOf(
                    Color(0xFFE0F7FA),
                    CyanGlowPrimary,
                    ElectricBlueSecondary,
                    Color(0xFF002F4D),
                    Color(0xFF04101A)
                )
                OrbState.IDLE -> listOf(
                    Color(0xFFCCF8FF),
                    CyanGlowPrimary,
                    Color(0xFF009EB3),
                    Color(0xFF003844),
                    Color(0xFF081320)
                )
            }

            // Draw core gradient
            drawCircle(
                brush = Brush.radialGradient(
                    colors = coreColors,
                    center = Offset(center.x - (currentCoreRadius * 0.18f), center.y - (currentCoreRadius * 0.18f)),
                    radius = currentCoreRadius
                ),
                radius = currentCoreRadius,
                center = center
            )

            // 5. Specular highlight for glassy holographic sphere finish
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.75f),
                        Color.White.copy(alpha = 0.2f),
                        Color.Transparent
                    ),
                    center = Offset(center.x - (currentCoreRadius * 0.32f), center.y - (currentCoreRadius * 0.32f)),
                    radius = currentCoreRadius * 0.42f
                ),
                radius = currentCoreRadius * 0.42f,
                center = Offset(center.x - (currentCoreRadius * 0.32f), center.y - (currentCoreRadius * 0.32f))
            )
        }
    }
}

@Composable
fun SabaOrbWithVisualizer(
    state: OrbState,
    amplitude: Float,
    statusLabel: String,
    modifier: Modifier = Modifier,
    size: Dp = 230.dp,
    onOrbClick: () -> Unit
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        SabaOrb(
            state = state,
            amplitude = amplitude,
            orbSize = size,
            onClick = onOrbClick
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Soundwave / Activity visualizer bars
        SoundwaveVisualizer(
            state = state,
            amplitude = amplitude
        )

        Spacer(modifier = Modifier.height(10.dp))

        // State indicator text
        Text(
            text = statusLabel,
            color = when (state) {
                OrbState.LISTENING -> NeonMintTertiary
                OrbState.SPEAKING -> ElectricBlueSecondary
                OrbState.THINKING -> CyanGlowBright
                OrbState.IDLE -> TextMuted
            },
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 1.1.sp
        )
    }
}

@Composable
fun SoundwaveVisualizer(
    state: OrbState,
    amplitude: Float,
    modifier: Modifier = Modifier
) {
    val barCount = 13
    val infiniteTransition = rememberInfiniteTransition(label = "wave_bars")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    Row(
        modifier = modifier.height(28.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until barCount) {
            val normalizedIndex = (i - (barCount / 2f)) / (barCount / 2f)
            val bellCurve = 1.0f - (normalizedIndex * normalizedIndex * 0.7f)

            val heightFactor = when (state) {
                OrbState.LISTENING -> (0.25f + (amplitude * 0.75f * (0.6f + 0.4f * sin(phase + i * 0.5f)))).coerceIn(0.15f, 1.0f)
                OrbState.SPEAKING -> (0.3f + (amplitude * 0.7f * (0.5f + 0.5f * sin(phase * 1.5f + i * 0.7f)))).coerceIn(0.2f, 1.0f)
                OrbState.THINKING -> (0.2f + 0.5f * (sin(phase + i * 0.8f) + 1f) / 2f).coerceIn(0.15f, 0.8f)
                OrbState.IDLE -> 0.12f
            }

            val barHeight = (28.dp * heightFactor * bellCurve).coerceAtLeast(4.dp)
            val barColor = when (state) {
                OrbState.LISTENING -> NeonMintTertiary
                OrbState.SPEAKING -> ElectricBlueSecondary
                OrbState.THINKING -> CyanGlowBright
                OrbState.IDLE -> Color(0xFF1E3552)
            }

            Box(
                modifier = Modifier
                    .size(width = 3.5.dp, height = barHeight)
                    .clip(CircleShape)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(color = barColor)
                }
            }
        }
    }
}
