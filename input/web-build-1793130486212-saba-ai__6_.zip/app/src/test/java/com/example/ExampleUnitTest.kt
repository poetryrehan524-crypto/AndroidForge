package com.example

import com.example.data.model.AssistantAction
import com.example.data.model.ProcessedResponse
import com.example.util.ConfigHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testActionTagParsing() {
        val openAppAction = AssistantAction.fromTag("OPEN_APP", "camera")
        assertNotNull(openAppAction)
        assertTrue(openAppAction is AssistantAction.OpenApp)
        assertEquals("camera", (openAppAction as AssistantAction.OpenApp).appKey)

        val openUrlAction = AssistantAction.fromTag("OPEN_URL", "https://google.com")
        assertNotNull(openUrlAction)
        assertTrue(openUrlAction is AssistantAction.OpenUrl)
        assertEquals("https://google.com", (openUrlAction as AssistantAction.OpenUrl).url)

        val searchAction = AssistantAction.fromTag("SEARCH", "Iron Man JARVIS")
        assertNotNull(searchAction)
        assertTrue(searchAction is AssistantAction.WebSearch)
        assertEquals("Iron Man JARVIS", (searchAction as AssistantAction.WebSearch).query)

        val dialAction = AssistantAction.fromTag("DIAL", "911")
        assertNotNull(dialAction)
        assertTrue(dialAction is AssistantAction.DialNumber)
        assertEquals("911", (dialAction as AssistantAction.DialNumber).number)
    }

    @Test
    fun testProcessedResponse() {
        val missingKeyResponse = ProcessedResponse(
            spokenText = "Key missing",
            isApiKeyMissing = true,
            isOnlineResponse = false
        )
        assertTrue(missingKeyResponse.isApiKeyMissing)
        assertEquals("Key missing", missingKeyResponse.spokenText)

        val onlineResponse = ProcessedResponse(
            spokenText = "Online intelligence active",
            isApiKeyMissing = false,
            isOnlineResponse = true
        )
        assertTrue(onlineResponse.isOnlineResponse)
    }

    @Test
    fun testConfigHelperMasking() {
        assertNotNull(ConfigHelper.getMaskedApiKey())
        assertNotNull(ConfigHelper.getKeySourceDescription())

        ConfigHelper.setRuntimeApiKey("AIzaSyTestKey123456789")
        assertTrue(ConfigHelper.hasValidGeminiApiKey())
        assertEquals("AIza...6789", ConfigHelper.getMaskedApiKey())

        // Reset
        ConfigHelper.setRuntimeApiKey("")
    }
}
