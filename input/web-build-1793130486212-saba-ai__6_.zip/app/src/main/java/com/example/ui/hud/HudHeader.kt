package com.example.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArcBlue
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HudBorderCyan
import com.example.ui.theme.HudSurfaceCard
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.NeonAccentGreen
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HudHeader(
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    isOnline: Boolean = true,
    modifier: Modifier = Modifier
) {
    var currentTime by remember {
        mutableStateOf(SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: SABA System Identity (Clickable to open Settings & see status)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onOpenSettings() }
                    .padding(4.dp)
                    .testTag("saba_header_identity")
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isOnline) NeonAccentGreen else Color(0xFFFFB300))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "SABA AI // v2.4",
                        color = ElectricCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = if (isOnline) "NEURAL LINK: ONLINE" else "NEURAL LINK: TAP TO CONFIGURE",
                        color = if (isOnline) NeonAccentGreen else Color(0xFFFFB300),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Right: Navigation Action Buttons & Clock
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Clock Pill
                Box(
                    modifier = Modifier
                        .background(HudSurfaceCard, RoundedCornerShape(8.dp))
                        .border(1.dp, HudBorderCyan, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = currentTime,
                        color = ElectricCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // History button with 48dp minimum touch target
                IconButton(
                    onClick = onOpenHistory,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(HudSurfaceCard.copy(alpha = 0.5f))
                        .testTag("history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Chat History",
                        tint = ElectricCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Settings button with 48dp minimum touch target
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(HudSurfaceCard.copy(alpha = 0.5f))
                        .border(1.dp, if (!isOnline) Color(0xFFFFB300) else HudBorderCyan, CircleShape)
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = if (!isOnline) Color(0xFFFFB300) else ElectricCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Futuristic Sub-Telemetry Line (also clickable to open settings)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .clickable { onOpenSettings() }
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isOnline) "GEMINI 2.5 FLASH // ONLINE" else "GEMINI: TAP TO CONFIGURE API KEY",
                color = if (isOnline) ArcBlue else Color(0xFFFFB300),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "SYS: OPTIMAL // 99.8%",
                color = ArcBlue,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
