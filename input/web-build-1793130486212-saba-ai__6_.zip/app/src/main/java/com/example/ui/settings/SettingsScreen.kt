package com.example.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArcBlue
import com.example.ui.theme.DeepSpaceBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HudBorderCyan
import com.example.ui.theme.HudSurfaceCard
import com.example.ui.theme.HudSurfaceDark
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.NeonAccentGreen
import com.example.ui.theme.NeonWarningRed
import com.example.util.ConfigHelper

@Composable
fun SettingsScreen(
    voicePitch: Float,
    speechRate: Float,
    language: String,
    memoryEnabled: Boolean,
    contextLimit: Int,
    continuousMode: Boolean,
    isMicPermissionGranted: Boolean,
    customApiKey: String = "",
    isApiKeyConfigured: Boolean = false,
    onPitchChange: (Float) -> Unit,
    onRateChange: (Float) -> Unit,
    onLanguageChange: (String) -> Unit,
    onMemoryToggle: (Boolean) -> Unit,
    onContextLimitChange: (Int) -> Unit,
    onContinuousModeToggle: (Boolean) -> Unit,
    onRequestMicPermission: () -> Unit,
    onTestVoice: () -> Unit,
    onSaveCustomApiKey: (String) -> Unit = {},
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var inputKey by remember(customApiKey) { mutableStateOf(customApiKey) }
    var isKeyVisible by remember { mutableStateOf(false) }
    var showSavedConfirm by remember { mutableStateOf(false) }
    var localKeyActive by remember(isApiKeyConfigured, customApiKey) {
        mutableStateOf(isApiKeyConfigured || ConfigHelper.hasValidGeminiApiKey())
    }

    val hasGeminiApiKey = localKeyActive || isApiKeyConfigured || ConfigHelper.hasValidGeminiApiKey()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepSpaceBlack)
    ) {
        // Top Bar with guaranteed 48dp+ interactive touch targets
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to HUD",
                    tint = ElectricCyan,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "SETTINGS // SABA AI",
                color = ElectricCyan,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.1.sp
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Gemini Neural Core Status & Configuration (AndroidForge & Local)
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.5.dp,
                        if (hasGeminiApiKey) NeonAccentGreen else Color(0xFFFFB300),
                        RoundedCornerShape(14.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = if (hasGeminiApiKey) NeonAccentGreen else Color(0xFFFFB300),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GEMINI API KEY CONFIGURATION",
                            color = ElectricCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (hasGeminiApiKey) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (hasGeminiApiKey) NeonAccentGreen else Color(0xFFFFB300),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (hasGeminiApiKey) "ONLINE // Key Active (${ConfigHelper.getMaskedApiKey()})" else "SETUP REQUIRED // KEY NOT CONFIGURED",
                            color = if (hasGeminiApiKey) NeonAccentGreen else Color(0xFFFFB300),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Source: ${ConfigHelper.getKeySourceDescription()}",
                        color = HudTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Direct Key Input on Device (Immediate solution for external APKs)
                    Text(
                        text = "ENTER OR PASTE YOUR GEMINI API KEY:",
                        color = ElectricCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = inputKey,
                        onValueChange = {
                            inputKey = it
                            showSavedConfirm = false
                        },
                        placeholder = { Text("AIzaSy...", color = HudTextSecondary, fontSize = 13.sp) },
                        visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(
                                onClick = { isKeyVisible = !isKeyVisible },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle key visibility",
                                    tint = ElectricCyan
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyan,
                            unfocusedBorderColor = HudBorderCyan,
                            focusedTextColor = HudTextPrimary,
                            unfocusedTextColor = HudTextPrimary,
                            focusedContainerColor = HudSurfaceDark,
                            unfocusedContainerColor = HudSurfaceDark
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_key_input_field")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                val clean = inputKey.trim()
                                if (clean.isNotBlank()) {
                                    onSaveCustomApiKey(clean)
                                    localKeyActive = true
                                    showSavedConfirm = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("save_api_key_button")
                        ) {
                            Text(
                                text = "SAVE KEY ON DEVICE",
                                color = DeepSpaceBlack,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (showSavedConfirm) {
                            Text(
                                text = "SAVED & CONNECTED!",
                                color = NeonAccentGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // External Build Instructions
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(HudSurfaceDark)
                            .border(1.dp, HudBorderCyan, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = "HOW TO SUPPLY KEY IN ANDROIDFORGE / CI:",
                                color = ElectricCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "• Option 1 (In-App Entry): Simply paste your key in the box above and tap SAVE KEY ON DEVICE.\n\n• Option 2 (AndroidForge Environment Variable): In AndroidForge project settings, add an Environment Variable named GEMINI_API_KEY with your key value.\n\n• Option 3 (local.properties): In your project root, add GEMINI_API_KEY=your_key in 'local.properties'.",
                                color = HudTextPrimary,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            // 2. Voice Telemetry Calibration Card
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "VOICE ENGINE CALIBRATION",
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Pitch Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Voice Pitch (Feminine Warmth)", color = HudTextPrimary, fontSize = 13.sp)
                        Text(
                            text = String.format("%.2f", voicePitch),
                            color = ElectricCyan,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Slider(
                        value = voicePitch,
                        onValueChange = onPitchChange,
                        valueRange = 0.6f..1.8f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricCyan,
                            activeTrackColor = ElectricCyan,
                            inactiveTrackColor = HudSurfaceDark
                        ),
                        modifier = Modifier.testTag("pitch_slider")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Speech Rate Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Speech Rate (Cadence)", color = HudTextPrimary, fontSize = 13.sp)
                        Text(
                            text = String.format("%.2f", speechRate),
                            color = ElectricCyan,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Slider(
                        value = speechRate,
                        onValueChange = onRateChange,
                        valueRange = 0.7f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricCyan,
                            activeTrackColor = ElectricCyan,
                            inactiveTrackColor = HudSurfaceDark
                        ),
                        modifier = Modifier.testTag("speech_rate_slider")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onTestVoice,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("test_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "TEST SABA VOICE OUTPUT", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // 3. Microphone Hardware Permissions Card
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = null,
                                tint = if (isMicPermissionGranted) NeonAccentGreen else NeonWarningRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Microphone Sensor Access",
                                    color = HudTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isMicPermissionGranted) "STATUS: SENSORS ACTIVE" else "STATUS: PERMISSION REQUIRED",
                                    color = if (isMicPermissionGranted) NeonAccentGreen else NeonWarningRed,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        if (!isMicPermissionGranted) {
                            Button(
                                onClick = onRequestMicPermission,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .height(44.dp)
                                    .testTag("request_mic_perm_button")
                            ) {
                                Text(text = "GRANT", color = DeepSpaceBlack, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 4. Conversation Continuity Mode
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Continuous Listening Mode",
                            color = HudTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Auto-reopens mic after SABA finishes speaking",
                            color = HudTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = continuousMode,
                        onCheckedChange = onContinuousModeToggle,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DeepSpaceBlack,
                            checkedTrackColor = ElectricCyan
                        ),
                        modifier = Modifier.testTag("continuous_mode_switch")
                    )
                }
            }

            // 5. Preferred Language Style
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "RESPONSE LANGUAGE STYLE",
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val langOptions = listOf(
                        "hinglish" to "Hinglish (Jaan, Babu)",
                        "hi" to "Hindi (हिंदी)",
                        "en" to "English"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        langOptions.forEach { (code, label) ->
                            val selected = language == code
                            FilterChip(
                                selected = selected,
                                onClick = { onLanguageChange(code) },
                                label = {
                                    Text(
                                        text = label,
                                        fontSize = 11.sp,
                                        color = if (selected) DeepSpaceBlack else HudTextPrimary
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricCyan,
                                    containerColor = HudSurfaceDark
                                ),
                                modifier = Modifier
                                    .height(44.dp)
                                    .testTag("lang_chip_$code")
                            )
                        }
                    }
                }
            }

            // 6. Context Memory Depth & Privacy
            Card(
                colors = CardDefaults.cardColors(containerColor = HudSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, HudBorderCyan, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Conversation Context Memory",
                                color = HudTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Recall previous turns for continuous chat",
                                color = HudTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = memoryEnabled,
                            onCheckedChange = onMemoryToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = DeepSpaceBlack,
                                checkedTrackColor = ElectricCyan
                            ),
                            modifier = Modifier.testTag("memory_toggle_switch")
                        )
                    }

                    if (memoryEnabled) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Memory Window (Turns)", color = HudTextPrimary, fontSize = 12.sp)
                            Text(
                                text = "$contextLimit turns",
                                color = ElectricCyan,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Slider(
                            value = contextLimit.toFloat(),
                            onValueChange = { onContextLimitChange(it.toInt()) },
                            valueRange = 2f..20f,
                            steps = 18,
                            colors = SliderDefaults.colors(
                                thumbColor = ElectricCyan,
                                activeTrackColor = ElectricCyan,
                                inactiveTrackColor = HudSurfaceDark
                            ),
                            modifier = Modifier.testTag("context_limit_slider")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
