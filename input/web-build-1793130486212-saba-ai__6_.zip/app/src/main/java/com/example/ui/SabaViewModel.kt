package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.actions.IntentDispatcher
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.model.AssistantAction
import com.example.data.preferences.SettingsManager
import com.example.data.remote.GeminiService
import com.example.ui.components.AiCoreState
import com.example.util.ConfigHelper
import com.example.voice.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen {
    HUD,
    CHAT_HISTORY,
    SETTINGS
}

class SabaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val conversationDao = database.conversationDao()
    private val settingsManager = SettingsManager(application)
    private val geminiService = GeminiService()
    private val intentDispatcher = IntentDispatcher(application)

    private val _currentScreen = MutableStateFlow(Screen.HUD)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _aiCoreState = MutableStateFlow(AiCoreState.IDLE)
    val aiCoreState: StateFlow<AiCoreState> = _aiCoreState.asStateFlow()

    private val _liveUserText = MutableStateFlow("")
    val liveUserText: StateFlow<String> = _liveUserText.asStateFlow()

    private val hasKey = ConfigHelper.hasValidGeminiApiKey()

    private val _liveAssistantText = MutableStateFlow(
        if (hasKey) "Suno na Jaan! Main SABA hoon, tumhari pyaari companion. Batao Babu, aaj ka din kaisa raha?"
        else "Suno na Jaan! Main yahan hoon. Bas ek baar local.properties ya Secrets panel mein GEMINI_API_KEY daal do na Babu, phir hum dher saari baatein karenge!"
    )
    val liveAssistantText: StateFlow<String> = _liveAssistantText.asStateFlow()

    private val _isApiKeyMissing = MutableStateFlow(!hasKey)
    val isApiKeyMissing: StateFlow<Boolean> = _isApiKeyMissing.asStateFlow()

    private val _isOnline = MutableStateFlow(hasKey)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _lastAction = MutableStateFlow<AssistantAction?>(null)
    val lastAction: StateFlow<AssistantAction?> = _lastAction.asStateFlow()

    private val _actionStatusMessage = MutableStateFlow<String?>(null)
    val actionStatusMessage: StateFlow<String?> = _actionStatusMessage.asStateFlow()

    val conversationHistory: StateFlow<List<ChatMessageEntity>> =
        conversationDao.getAllMessages()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val voicePitch = settingsManager.voicePitch
    val speechRate = settingsManager.speechRate
    val language = settingsManager.language
    val memoryEnabled = settingsManager.memoryEnabled
    val contextLimit = settingsManager.contextLimit
    val continuousMode = settingsManager.continuousMode
    val customApiKey = settingsManager.customApiKey

    private val voiceManager = VoiceManager(
        context = application,
        onSpeechResult = { recognizedText ->
            processCommand(recognizedText)
        }
    )

    val isListening: StateFlow<Boolean> = voiceManager.isListening
    val isSpeaking: StateFlow<Boolean> = voiceManager.isSpeaking
    val audioRms: StateFlow<Float> = voiceManager.audioRms
    val statusMessage: StateFlow<String> = voiceManager.statusMessage

    init {
        if (!hasKey) {
            voiceManager.setStatus("SETUP: GEMINI_API_KEY MISSING")
        }

        viewModelScope.launch {
            voiceManager.isListening.collect { listening ->
                if (listening) {
                    _aiCoreState.value = AiCoreState.LISTENING
                } else if (_aiCoreState.value == AiCoreState.LISTENING) {
                    _aiCoreState.value = AiCoreState.IDLE
                }
            }
        }

        viewModelScope.launch {
            voiceManager.isSpeaking.collect { speaking ->
                if (speaking) {
                    _aiCoreState.value = AiCoreState.SPEAKING
                } else if (_aiCoreState.value == AiCoreState.SPEAKING) {
                    _aiCoreState.value = AiCoreState.IDLE
                }
            }
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun toggleListening() {
        if (voiceManager.isSpeaking.value) {
            voiceManager.stopSpeaking()
            _aiCoreState.value = AiCoreState.IDLE
            return
        }

        if (voiceManager.isListening.value) {
            voiceManager.stopListening()
            _aiCoreState.value = AiCoreState.IDLE
        } else {
            voiceManager.startListening(language.value)
        }
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
        _aiCoreState.value = AiCoreState.IDLE
    }

    fun processCommand(command: String) {
        if (command.isBlank()) return

        var cleanCommand = command.trim()
        val wakeRegex = Regex("^(hey\\s+saba|saba|saba\\s+ai)[,\\s]*", RegexOption.IGNORE_CASE)
        val matched = wakeRegex.find(cleanCommand)
        if (matched != null && cleanCommand.length > matched.value.length) {
            cleanCommand = cleanCommand.substring(matched.range.last + 1).trim()
        }

        _liveUserText.value = command
        _aiCoreState.value = AiCoreState.THINKING
        voiceManager.setStatus("ANALYZING // GEMINI NEURAL NET...")

        viewModelScope.launch {
            conversationDao.insertMessage(
                ChatMessageEntity(
                    role = "user",
                    content = command
                )
            )

            val recentContext = if (memoryEnabled.value) {
                conversationDao.getRecentMessages(contextLimit.value).reversed()
            } else {
                emptyList()
            }

            val processed = geminiService.generateResponse(
                userMessage = cleanCommand,
                recentHistory = recentContext,
                languagePref = language.value
            )

            _liveAssistantText.value = processed.spokenText
            _lastAction.value = processed.action
            _isApiKeyMissing.value = processed.isApiKeyMissing
            _isOnline.value = processed.isOnlineResponse

            var actionStatus: String? = null
            if (processed.action != null) {
                val result = intentDispatcher.executeAction(processed.action)
                actionStatus = result.message
                _actionStatusMessage.value = result.message
            } else {
                _actionStatusMessage.value = null
            }

            if (processed.isApiKeyMissing) {
                voiceManager.setStatus("SETUP: GEMINI_API_KEY MISSING")
            }

            conversationDao.insertMessage(
                ChatMessageEntity(
                    role = "saba",
                    content = processed.spokenText,
                    actionType = processed.action?.type,
                    actionPayload = processed.action?.payload,
                    actionStatus = if (processed.action != null) "EXECUTED" else null
                )
            )

            _aiCoreState.value = if (processed.isApiKeyMissing) AiCoreState.ERROR else AiCoreState.SPEAKING
            voiceManager.speak(
                text = processed.spokenText,
                pitch = voicePitch.value,
                speed = speechRate.value,
                language = language.value,
                onDone = {
                    if (continuousMode.value && !processed.isApiKeyMissing) {
                        voiceManager.startListening(language.value)
                    }
                }
            )
        }
    }

    fun executeActionManually(action: AssistantAction) {
        viewModelScope.launch {
            val result = intentDispatcher.executeAction(action)
            _actionStatusMessage.value = result.message
        }
    }

    fun replayCurrentSpeech() {
        val text = _liveAssistantText.value
        if (text.isNotBlank()) {
            _aiCoreState.value = AiCoreState.SPEAKING
            voiceManager.speak(
                text = text,
                pitch = voicePitch.value,
                speed = speechRate.value,
                language = language.value
            )
        }
    }

    fun testVoiceOutput() {
        voiceManager.speak(
            text = "Suno na Jaan! Main tumhari SABA hoon. Meri aawaz theek lag rahi hai na Babu?",
            pitch = voicePitch.value,
            speed = speechRate.value,
            language = language.value
        )
    }

    fun deleteMessage(id: Long) {
        viewModelScope.launch {
            conversationDao.deleteMessage(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            conversationDao.clearAllMessages()
            _liveUserText.value = ""
            val keyReady = ConfigHelper.hasValidGeminiApiKey()
            _liveAssistantText.value = if (keyReady) "Suno na Jaan, purani saari baatein clear kar di maine. Ab ek nayi shuruat karte hain Babu!"
            else "Memory clear ho gayi Jaan! Online baatein karne ke liye local.properties mein GEMINI_API_KEY daal do na!"
            _lastAction.value = null
            _actionStatusMessage.value = null
        }
    }

    fun setVoicePitch(pitch: Float) = settingsManager.setVoicePitch(pitch)
    fun setSpeechRate(rate: Float) = settingsManager.setSpeechRate(rate)
    fun setLanguage(lang: String) = settingsManager.setLanguage(lang)
    fun setMemoryEnabled(enabled: Boolean) = settingsManager.setMemoryEnabled(enabled)
    fun setContextLimit(limit: Int) = settingsManager.setContextLimit(limit)
    fun setContinuousMode(enabled: Boolean) = settingsManager.setContinuousMode(enabled)

    fun setCustomApiKey(key: String) {
        settingsManager.setCustomApiKey(key)
        val valid = ConfigHelper.hasValidGeminiApiKey()
        _isApiKeyMissing.value = !valid
        _isOnline.value = valid
        if (valid) {
            voiceManager.setStatus("ONLINE // GEMINI CONNECTED")
            _liveAssistantText.value = "Suno na Jaan! Main online Gemini se connect ho gayi hoon! Ab pucho jo puchna hai Babu!"
            voiceManager.speak(
                text = "Suno na Jaan! Main online Gemini se connect ho gayi hoon! Ab pucho jo puchna hai Babu!",
                pitch = voicePitch.value,
                speed = speechRate.value,
                language = language.value
            )
        } else {
            voiceManager.setStatus("SETUP: GEMINI_API_KEY MISSING")
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
