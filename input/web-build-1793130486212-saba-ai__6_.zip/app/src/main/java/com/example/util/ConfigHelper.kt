package com.example.util

import com.example.BuildConfig

object ConfigHelper {
    private var runtimeApiKey: String = ""

    fun setRuntimeApiKey(key: String) {
        runtimeApiKey = key.trim()
    }

    fun getGeminiApiKey(): String {
        // 1. Check in-memory runtime key
        if (runtimeApiKey.isNotBlank() && runtimeApiKey != "MY_GEMINI_API_KEY") {
            return runtimeApiKey
        }

        // 2. Check BuildConfig (injected at build time via AndroidForge env var, local.properties, gradle.properties, or -P)
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isNotBlank() && key != "MY_GEMINI_API_KEY") {
                key.trim()
            } else {
                val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
                val dynamicKey = (field.get(null) as? String)?.trim() ?: ""
                if (dynamicKey.isNotBlank() && dynamicKey != "MY_GEMINI_API_KEY") dynamicKey else ""
            }
        } catch (_: Throwable) {
            ""
        }
    }

    fun hasValidGeminiApiKey(): Boolean {
        val key = getGeminiApiKey()
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    fun getMaskedApiKey(): String {
        val key = getGeminiApiKey()
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") return "NOT CONFIGURED"
        return if (key.length <= 8) {
            "******"
        } else {
            "${key.take(4)}...${key.takeLast(4)}"
        }
    }

    fun getKeySourceDescription(): String {
        val buildKey = try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isNotBlank() && key != "MY_GEMINI_API_KEY") key.trim() else ""
        } catch (_: Throwable) { "" }

        if (buildKey.isNotBlank()) {
            return "Active: Injected into BuildConfig (via AndroidForge env var / local.properties)"
        }

        if (runtimeApiKey.isNotBlank() && runtimeApiKey != "MY_GEMINI_API_KEY") {
            return "Active: Saved securely in App Settings (On-Device Storage)"
        }

        return "Missing: Configure GEMINI_API_KEY in AndroidForge build or enter key in Settings"
    }
}
