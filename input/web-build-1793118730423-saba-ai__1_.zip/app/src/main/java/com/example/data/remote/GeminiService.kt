package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.example.data.local.ChatMessageEntity
import com.example.data.model.AssistantAction
import com.example.data.model.ProcessedResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class GeminiService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    private val tag = "GeminiService"
    private val actionPattern = Pattern.compile("\\[ACTION:([A-Za-z0-9_]+),\\s*([^\\]]+)\\]")

    private val systemInstruction = """
You are SABA AI (Strategic Autonomous Binary Assistant), a hyper-intelligent, calm, witty, and exceptionally loyal AI assistant inspired by Iron Man's JARVIS.
You understand and respond fluently in English, pure Hindi (Devanagari or Roman Hindi), and Hinglish (natural conversational Hindi-English blend).
Always match the language or blend that the user speaks to you with (e.g. if the user speaks Hinglish like "Mera camera kholo ya YouTube chalao", reply in crisp Hinglish like "Ji Sir, abhi camera activate kar rahi hoon.").

IMPORTANT CAPABILITY: You can trigger real device actions and open apps on the user's Android phone!
Whenever the user asks you to open an app, search something, visit a website, or make a call, output an action tag at the end of your response:
1. Open camera: [ACTION:OPEN_APP, name=camera]
2. Open YouTube: [ACTION:OPEN_APP, name=youtube]
3. Open Maps / Navigation: [ACTION:OPEN_APP, name=maps]
4. Open WhatsApp: [ACTION:OPEN_APP, name=whatsapp]
5. Open Calculator: [ACTION:OPEN_APP, name=calculator]
6. Open Settings: [ACTION:OPEN_APP, name=settings]
7. Open Clock / Alarms / Timer: [ACTION:OPEN_APP, name=clock]
8. Open Chrome / Browser: [ACTION:OPEN_APP, name=browser]
9. Open a specific web URL: [ACTION:OPEN_URL, url=https://...]
10. Search Google or Web: [ACTION:SEARCH, query=...]
11. Call or Dial a number: [ACTION:DIAL, number=...]

Keep your vocal replies concise, polished, and futuristic (1-3 sentences maximum) so they sound amazing when spoken through TextToSpeech. Address the user with respect (e.g. 'Sir' or 'Boss' or polite tone 'Ji'). If the user asks about yourself, introduce yourself as SABA AI.
""".trimIndent()

    suspend fun generateResponse(
        userMessage: String,
        recentHistory: List<ChatMessageEntity> = emptyList(),
        languagePref: String = "auto"
    ): ProcessedResponse = withContext(Dispatchers.IO) {
        val apiKey = com.example.util.ConfigHelper.getGeminiApiKey()

        // If API key is missing or dummy placeholder, try smart local execution or guide user
        val isDummyOrMissing = apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY"

        if (isDummyOrMissing) {
            return@withContext handleLocalFallback(userMessage)
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

            val requestBodyJson = JSONObject()

            // System Instruction
            val sysInstructionObj = JSONObject()
            val sysParts = JSONArray()
            sysParts.put(JSONObject().put("text", systemInstruction))
            sysInstructionObj.put("parts", sysParts)
            requestBodyJson.put("system_instruction", sysInstructionObj)

            // Conversation Contents
            val contentsArray = JSONArray()

            // History context
            recentHistory.forEach { msg ->
                val role = if (msg.role == "user") "user" else "model"
                val contentObj = JSONObject()
                contentObj.put("role", role)
                val parts = JSONArray()
                parts.put(JSONObject().put("text", msg.content))
                contentObj.put("parts", parts)
                contentsArray.put(contentObj)
            }

            // Current user turn
            val currentUserObj = JSONObject()
            currentUserObj.put("role", "user")
            val userParts = JSONArray()
            var promptText = userMessage
            if (languagePref != "auto") {
                promptText += " [User preferred response language style: $languagePref]"
            }
            userParts.put(JSONObject().put("text", promptText))
            currentUserObj.put("parts", userParts)
            contentsArray.put(currentUserObj)

            requestBodyJson.put("contents", contentsArray)

            // Generation Config
            val genConfig = JSONObject()
            genConfig.put("temperature", 0.7)
            genConfig.put("maxOutputTokens", 600)
            requestBodyJson.put("generationConfig", genConfig)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestBodyJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val responseString = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    Log.e(tag, "Gemini API error code ${response.code}: $responseString")
                    // If model quota or error, provide graceful fallback
                    return@withContext handleLocalFallback(userMessage, isError = true)
                }

                val jsonResponse = JSONObject(responseString)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).optString("text", "")
                        return@withContext parseResponse(text)
                    }
                }
                return@withContext handleLocalFallback(userMessage)
            }
        } catch (e: Exception) {
            Log.e(tag, "Exception during Gemini API request", e)
            return@withContext handleLocalFallback(userMessage, isError = true)
        }
    }

    private fun parseResponse(rawText: String): ProcessedResponse {
        var cleanText = rawText
        var extractedAction: AssistantAction? = null

        val matcher = actionPattern.matcher(rawText)
        if (matcher.find()) {
            val tagType = matcher.group(1) ?: ""
            val fullPayload = matcher.group(2) ?: ""

            // Extract key-value if present, e.g. name=camera or url=...
            val payloadValue = if (fullPayload.contains("=")) {
                fullPayload.substringAfter("=").trim()
            } else {
                fullPayload.trim()
            }

            extractedAction = AssistantAction.fromTag(tagType, payloadValue)
            cleanText = rawText.replace(matcher.group(0) ?: "", "").trim()
        }

        // Clean out extra markdown formatting that sounds weird when spoken
        cleanText = cleanText
            .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
            .replace(Regex("\\*([^*]+)\\*"), "$1")
            .replace(Regex("`([^`]+)`"), "$1")
            .replace(Regex("#+\\s*"), "")
            .trim()

        return ProcessedResponse(
            spokenText = cleanText,
            action = extractedAction,
            rawResponse = rawText
        )
    }

    /**
     * Offline & local fallback parser:
     * Understands Hindi, Hinglish, and English commands for device actions,
     * greetings, and system diagnostics even if offline or before the API key is set.
     */
    private fun handleLocalFallback(userMessage: String, isError: Boolean = false): ProcessedResponse {
        val lower = userMessage.lowercase().trim()

        // 1. Camera intents
        if (lower.contains("camera") || lower.contains("photo") || lower.contains("tasveer") || lower.contains("khicho")) {
            return ProcessedResponse(
                spokenText = "Activating camera optical sensors, Sir.",
                action = AssistantAction.OpenApp("camera"),
                rawResponse = "Activating camera [ACTION:OPEN_APP, name=camera]"
            )
        }

        // 2. YouTube intents
        if (lower.contains("youtube") || lower.contains("video") || lower.contains("song") || lower.contains("gaana")) {
            return ProcessedResponse(
                spokenText = "Accessing YouTube visual stream now, Sir.",
                action = AssistantAction.OpenApp("youtube"),
                rawResponse = "Opening YouTube [ACTION:OPEN_APP, name=youtube]"
            )
        }

        // 3. Maps / Navigation
        if (lower.contains("map") || lower.contains("maps") || lower.contains("rasta") || lower.contains("location") || lower.contains("navigate")) {
            return ProcessedResponse(
                spokenText = "Plotting coordinates on Google Maps, Sir.",
                action = AssistantAction.OpenApp("maps"),
                rawResponse = "Opening Maps [ACTION:OPEN_APP, name=maps]"
            )
        }

        // 4. WhatsApp
        if (lower.contains("whatsapp") || lower.contains("message")) {
            return ProcessedResponse(
                spokenText = "Initiating WhatsApp communications channel.",
                action = AssistantAction.OpenApp("whatsapp"),
                rawResponse = "Opening WhatsApp [ACTION:OPEN_APP, name=whatsapp]"
            )
        }

        // 5. Calculator
        if (lower.contains("calculator") || lower.contains("calculate") || lower.contains("hisab") || lower.contains("ginti")) {
            return ProcessedResponse(
                spokenText = "Launching arithmetic matrix, Sir.",
                action = AssistantAction.OpenApp("calculator"),
                rawResponse = "Opening Calculator [ACTION:OPEN_APP, name=calculator]"
            )
        }

        // 6. Settings
        if (lower.contains("settings") || lower.contains("setting")) {
            return ProcessedResponse(
                spokenText = "Opening Android system control console.",
                action = AssistantAction.OpenApp("settings"),
                rawResponse = "Opening Settings [ACTION:OPEN_APP, name=settings]"
            )
        }

        // 7. Clock / Alarm / Timer
        if (lower.contains("clock") || lower.contains("alarm") || lower.contains("timer") || lower.contains("samay")) {
            return ProcessedResponse(
                spokenText = "Displaying temporal chronological alarms, Sir.",
                action = AssistantAction.OpenApp("clock"),
                rawResponse = "Opening Clock [ACTION:OPEN_APP, name=clock]"
            )
        }

        // 8. Search / Web
        if (lower.startsWith("search") || lower.contains("dhoondo") || lower.contains("google karo")) {
            val query = lower.replace("search for", "")
                .replace("search", "")
                .replace("google karo", "")
                .replace("dhoondo", "")
                .trim()
            val effectiveQuery = if (query.isNotBlank()) query else "Google"
            return ProcessedResponse(
                spokenText = "Executing web search for $effectiveQuery.",
                action = AssistantAction.WebSearch(effectiveQuery),
                rawResponse = "Searching web [ACTION:SEARCH, query=$effectiveQuery]"
            )
        }

        // 9. Call / Dial
        if (lower.contains("call") || lower.contains("dial") || lower.contains("phone")) {
            val digits = userMessage.filter { it.isDigit() }
            return ProcessedResponse(
                spokenText = "Opening communications dialer, Sir.",
                action = AssistantAction.DialNumber(digits),
                rawResponse = "Dialing [ACTION:DIAL, number=$digits]"
            )
        }

        // 10. Greetings & identity in Hindi, Hinglish, English
        if (lower.contains("hello") || lower.contains("hey saba") || lower.contains("namaste") || lower.contains("hi saba") || lower.contains("kaise ho")) {
            return ProcessedResponse(
                spokenText = "Namaste Sir! All systems are online and running at peak efficiency. SABA AI is at your service. Bataiye kya command hai?",
                rawResponse = "Namaste Sir! All systems online."
            )
        }

        if (lower.contains("who are you") || lower.contains("kaun ho") || lower.contains("tumhara naam")) {
            return ProcessedResponse(
                spokenText = "Main SABA AI hoon — Strategic Autonomous Binary Assistant. Inspired by JARVIS, designed to assist you with voice commands, device actions, and intelligence.",
                rawResponse = "I am SABA AI."
            )
        }

        if (lower.contains("iron man") || lower.contains("jarvis") || lower.contains("tony stark")) {
            return ProcessedResponse(
                spokenText = "A tribute to Mr. Stark's vision, Sir. Core arc reactor status is stable at 100%. Ready for your directive.",
                rawResponse = "Core arc reactor is stable at 100%."
            )
        }

        if (isError) {
            return ProcessedResponse(
                spokenText = "Neural uplink experienced high latency, Sir. However, all local device intent protocols remain operational.",
                rawResponse = "Neural connection blip."
            )
        }

        return ProcessedResponse(
            spokenText = "Protocol received, Sir. To unlock my full Gemini generative intellect, please ensure your GEMINI_API_KEY is configured in the Secrets panel. How may I assist you further?",
            rawResponse = "SABA standing by."
        )
    }
}
