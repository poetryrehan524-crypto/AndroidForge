package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class VoiceManager(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit
) {
    private val tag = "VoiceManager"
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    private val _statusMessage = MutableStateFlow("CORE READY")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var onSpeechDoneCallback: (() -> Unit)? = null

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsInitialized = true
                textToSpeech?.language = Locale.ENGLISH
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                        _statusMessage.value = "TRANSMITTING VOCAL RESPONSE..."
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            _isSpeaking.value = false
                            _statusMessage.value = "CORE READY"
                            onSpeechDoneCallback?.invoke()
                            onSpeechDoneCallback = null
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            _isSpeaking.value = false
                            _statusMessage.value = "CORE READY"
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        mainHandler.post {
                            _isSpeaking.value = false
                            _statusMessage.value = "CORE READY"
                        }
                    }
                })
                Log.d(tag, "TTS initialized successfully")
            } else {
                Log.e(tag, "Failed to initialize TTS: status=$status")
            }
        }
    }

    fun startListening(languagePref: String = "auto") {
        if (_isSpeaking.value) {
            stopSpeaking()
        }

        mainHandler.post {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                    _statusMessage.value = "SPEECH RECOGNIZER NOT AVAILABLE"
                    return@post
                }

                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

                    when (languagePref) {
                        "hi" -> {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                        }
                        "en" -> {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
                        }
                        else -> {
                            // Hinglish / Auto: Accept Hindi and English
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
                            putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayOf("en-IN", "hi-IN", "en-US"))
                        }
                    }
                }

                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                        _statusMessage.value = "LISTENING // AWAITING COMMAND..."
                    }

                    override fun onBeginningOfSpeech() {
                        _statusMessage.value = "RECEIVING VOCAL STREAM..."
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        // Normalize RMS (usually -2 to 10 dB) to 0f - 1f
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        _audioRms.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _isListening.value = false
                        _audioRms.value = 0f
                        _statusMessage.value = "ANALYZING NEURAL DATA..."
                    }

                    override fun onError(error: Int) {
                        _isListening.value = false
                        _audioRms.value = 0f
                        val reason = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "NO MATCH DETECTED"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "SPEECH TIMEOUT"
                            SpeechRecognizer.ERROR_AUDIO -> "AUDIO RECORD ERROR"
                            SpeechRecognizer.ERROR_CLIENT -> "CLIENT ERROR"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "MIC PERMISSION REQUIRED"
                            SpeechRecognizer.ERROR_NETWORK -> "NETWORK TIMEOUT"
                            else -> "READY"
                        }
                        _statusMessage.value = reason
                    }

                    override fun onResults(results: Bundle?) {
                        _isListening.value = false
                        _audioRms.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spoken = matches?.firstOrNull()?.trim()
                        if (!spoken.isNullOrBlank()) {
                            _statusMessage.value = "PROCESSING QUERY..."
                            onSpeechResult(spoken)
                        } else {
                            _statusMessage.value = "CORE READY"
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()
                        if (!text.isNullOrBlank()) {
                            _statusMessage.value = "HEARING: \"$text\""
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(tag, "Error starting speech recognition", e)
                _isListening.value = false
                _statusMessage.value = "SPEECH INIT ERROR"
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.e(tag, "Error stopping listener", e)
            }
            _isListening.value = false
            _audioRms.value = 0f
        }
    }

    fun speak(
        text: String,
        pitch: Float = 1.0f,
        speed: Float = 1.05f,
        language: String = "auto",
        onDone: (() -> Unit)? = null
    ) {
        if (!isTtsInitialized || text.isBlank()) {
            onDone?.invoke()
            return
        }

        stopListening()
        this.onSpeechDoneCallback = onDone

        try {
            textToSpeech?.setPitch(pitch.coerceIn(0.5f, 2.0f))
            textToSpeech?.setSpeechRate(speed.coerceIn(0.5f, 2.0f))

            // Configure language
            when (language) {
                "hi" -> {
                    val hiLocale = Locale("hi", "IN")
                    if ((textToSpeech?.isLanguageAvailable(hiLocale) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                        textToSpeech?.language = hiLocale
                    }
                }
                "en" -> {
                    textToSpeech?.language = Locale.US
                }
                else -> {
                    // Detect if text contains Devanagari Hindi characters
                    val hasHindiScript = text.any { it in '\u0900'..'\u097F' }
                    if (hasHindiScript) {
                        val hiLocale = Locale("hi", "IN")
                        if ((textToSpeech?.isLanguageAvailable(hiLocale) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                            textToSpeech?.language = hiLocale
                        }
                    } else {
                        textToSpeech?.language = Locale.ENGLISH
                    }
                }
            }

            val utteranceId = UUID.randomUUID().toString()
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (e: Exception) {
            Log.e(tag, "Error invoking TTS speak", e)
            _isSpeaking.value = false
            onDone?.invoke()
        }
    }

    fun stopSpeaking() {
        try {
            textToSpeech?.stop()
        } catch (e: Exception) {
            Log.e(tag, "Error stopping TTS", e)
        }
        _isSpeaking.value = false
        _statusMessage.value = "CORE READY"
    }

    fun setStatus(status: String) {
        _statusMessage.value = status
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (e: Exception) {
            Log.e(tag, "Error during destroy", e)
        }
    }
}
