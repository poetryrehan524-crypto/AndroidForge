package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SabaDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = Color(0xFF001F29),
    primaryContainer = Color(0xFF003D4E),
    onPrimaryContainer = Color(0xFF9CF4FF),
    secondary = ArcBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF002A66),
    onSecondaryContainer = Color(0xFFCCE0FF),
    tertiary = NeonAccentGreen,
    onTertiary = Color(0xFF002014),
    background = DeepSpaceBlack,
    onBackground = HudTextPrimary,
    surface = HudSurfaceDark,
    onSurface = HudTextPrimary,
    surfaceVariant = HudSurfaceCard,
    onSurfaceVariant = HudTextSecondary,
    outline = HudBorderCyan,
    error = NeonWarningRed,
    onError = Color.White
)

@Composable
fun SabaAiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SabaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
