package com.example.data.model

sealed class AssistantAction(val type: String, val payload: String) {
    class OpenApp(val appKey: String) : AssistantAction("OPEN_APP", appKey)
    class OpenUrl(val url: String) : AssistantAction("OPEN_URL", url)
    class WebSearch(val query: String) : AssistantAction("SEARCH", query)
    class DialNumber(val number: String) : AssistantAction("DIAL", number)

    companion object {
        fun fromTag(tagType: String, payload: String): AssistantAction? {
            return when (tagType.uppercase().trim()) {
                "OPEN_APP" -> OpenApp(payload.trim())
                "OPEN_URL" -> OpenUrl(payload.trim())
                "SEARCH" -> WebSearch(payload.trim())
                "DIAL" -> DialNumber(payload.trim())
                else -> null
            }
        }
    }
}

data class ProcessedResponse(
    val spokenText: String,
    val action: AssistantAction? = null,
    val rawResponse: String = spokenText
)
