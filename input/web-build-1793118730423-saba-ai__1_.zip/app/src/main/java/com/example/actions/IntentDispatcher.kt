package com.example.actions

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import com.example.data.model.AssistantAction

class IntentDispatcher(private val context: Context) {
    private val tag = "IntentDispatcher"

    fun executeAction(action: AssistantAction): ActionResult {
        return try {
            when (action) {
                is AssistantAction.OpenApp -> openAppByKey(action.appKey)
                is AssistantAction.OpenUrl -> openWebUrl(action.url)
                is AssistantAction.WebSearch -> executeWebSearch(action.query)
                is AssistantAction.DialNumber -> openDialer(action.number)
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to execute action $action", e)
            ActionResult(
                success = false,
                message = "Failed to launch action: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }

    private fun openAppByKey(appKey: String): ActionResult {
        val key = appKey.lowercase().trim()
        val pm = context.packageManager

        when {
            key.contains("camera") -> {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    return ActionResult(true, "Camera optical sensors activated")
                }
                // Fallback to media store capture
                val fallbackIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
                return ActionResult(true, "Camera activated")
            }

            key.contains("youtube") -> {
                val youtubeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (youtubeIntent.resolveActivity(pm) != null) {
                    context.startActivity(youtubeIntent)
                    return ActionResult(true, "YouTube opened")
                }
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
                return ActionResult(true, "YouTube opened in browser")
            }

            key.contains("maps") || key.contains("location") || key.contains("navigation") -> {
                val mapsUri = Uri.parse("geo:0,0?q=nearby")
                val mapsIntent = Intent(Intent.ACTION_VIEW, mapsUri).apply {
                    setPackage("com.google.android.apps.maps")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (mapsIntent.resolveActivity(pm) != null) {
                    context.startActivity(mapsIntent)
                    return ActionResult(true, "Google Maps coordinates opened")
                }
                val browserMaps = Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserMaps)
                return ActionResult(true, "Maps launched in browser")
            }

            key.contains("whatsapp") -> {
                val launchIntent = pm.getLaunchIntentForPackage("com.whatsapp")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return ActionResult(true, "WhatsApp communications opened")
                }
                val webWhatsApp = Intent(Intent.ACTION_VIEW, Uri.parse("https://web.whatsapp.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webWhatsApp)
                return ActionResult(true, "WhatsApp web opened")
            }

            key.contains("calculator") -> {
                val calcIntent = Intent().apply {
                    action = Intent.ACTION_MAIN
                    addCategory(Intent.CATEGORY_APP_CALCULATOR)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (calcIntent.resolveActivity(pm) != null) {
                    context.startActivity(calcIntent)
                    return ActionResult(true, "Calculator opened")
                }
                // Try common package names
                val calcPackages = listOf("com.google.android.calculator", "com.android.calculator2")
                for (pkg in calcPackages) {
                    val intent = pm.getLaunchIntentForPackage(pkg)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        return ActionResult(true, "Calculator opened")
                    }
                }
                return openWebUrl("https://www.google.com/search?q=calculator")
            }

            key.contains("clock") || key.contains("alarm") || key.contains("timer") -> {
                val alarmIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (alarmIntent.resolveActivity(pm) != null) {
                    context.startActivity(alarmIntent)
                    return ActionResult(true, "Clock & Alarms displayed")
                }
                return ActionResult(false, "Clock application not found")
            }

            key.contains("settings") -> {
                val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(settingsIntent)
                return ActionResult(true, "Android System Settings opened")
            }

            key.contains("browser") || key.contains("chrome") -> {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://google.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
                return ActionResult(true, "Browser opened")
            }

            else -> {
                // Try launching generic app by package or name
                val launchIntent = pm.getLaunchIntentForPackage(key)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return ActionResult(true, "App $key opened")
                }
                return executeWebSearch(appKey)
            }
        }
    }

    private fun openWebUrl(rawUrl: String): ActionResult {
        val formattedUrl = if (!rawUrl.startsWith("http://") && !rawUrl.startsWith("https://")) {
            "https://$rawUrl"
        } else rawUrl

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(formattedUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return ActionResult(true, "Navigated to $formattedUrl")
    }

    private fun executeWebSearch(query: String): ActionResult {
        val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val pm = context.packageManager
        if (searchIntent.resolveActivity(pm) != null) {
            context.startActivity(searchIntent)
            return ActionResult(true, "Web search initiated for \"$query\"")
        }
        // Fallback to direct Google search URL
        val escaped = Uri.encode(query)
        val url = "https://www.google.com/search?q=$escaped"
        return openWebUrl(url)
    }

    private fun openDialer(number: String): ActionResult {
        val dialUri = if (number.isNotBlank()) Uri.parse("tel:$number") else Uri.parse("tel:")
        val intent = Intent(Intent.ACTION_DIAL, dialUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return ActionResult(true, "Phone dialer opened ${if (number.isNotBlank()) "with $number" else ""}")
    }
}

data class ActionResult(
    val success: Boolean,
    val message: String
)
