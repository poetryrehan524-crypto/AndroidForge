package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ArcBlue
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonAccentGreen
import com.example.ui.theme.NeonWarningRed
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class AiCoreState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

@Composable
fun ArcReactorCore(
    coreState: AiCoreState,
    audioRms: Float,
    modifier: Modifier = Modifier,
    size: Dp = 260.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ReactorTransition")

    // Slow rotation for idle / normal state
    val normalRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "NormalRotation"
    )

    // Fast counter rotation for thinking state
    val fastCounterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "FastCounterRotation"
    )

    // Breathing pulse
    val breathingPulse by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathingPulse"
    )

    // Radar scan beam angle for thinking
    val scanBeamAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ScanBeamAngle"
    )

    // Speaking vocal wave cycle
    val vocalWaveCycle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "VocalWaveCycle"
    )

    val primaryColor = when (coreState) {
        AiCoreState.IDLE -> ElectricCyan
        AiCoreState.LISTENING -> ElectricCyan
        AiCoreState.THINKING -> Color(0xFF00E5FF)
        AiCoreState.SPEAKING -> NeonAccentGreen
        AiCoreState.ERROR -> NeonWarningRed
    }

    val secondaryColor = when (coreState) {
        AiCoreState.IDLE -> ArcBlue
        AiCoreState.LISTENING -> Color(0xFF00B0FF)
        AiCoreState.THINKING -> Color(0xFF7C4DFF)
        AiCoreState.SPEAKING -> Color(0xFF00E676)
        AiCoreState.ERROR -> Color(0xFFFF5252)
    }

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .size(size)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val maxRadius = (this.size.width / 2f) * 0.95f

            // Dynamic scaling based on state and microphone audio RMS
            val stateScale = when (coreState) {
                AiCoreState.IDLE -> breathingPulse
                AiCoreState.LISTENING -> (1f + audioRms * 0.28f)
                AiCoreState.THINKING -> 1.02f
                AiCoreState.SPEAKING -> (0.97f + sin(vocalWaveCycle) * 0.08f)
                AiCoreState.ERROR -> 1.0f
            }

            // 1. Ambient Radial Glow Background
            val glowRadius = maxRadius * 1.05f * stateScale
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = if (coreState == AiCoreState.LISTENING) 0.35f else 0.18f),
                        secondaryColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = glowRadius
                ),
                radius = glowRadius,
                center = center
            )

            // 2. Outermost Segmented Arc Ring (Rotating)
            val outerRadius = maxRadius * 0.90f * stateScale
            val outerRotation = when (coreState) {
                AiCoreState.THINKING -> fastCounterRotation
                AiCoreState.LISTENING -> normalRotation * 2.5f
                else -> normalRotation
            }

            rotate(outerRotation, pivot = center) {
                // 3 segments of 100 degrees with 20 deg gaps
                for (i in 0 until 3) {
                    val startAngle = i * 120f + 10f
                    drawArc(
                        color = primaryColor.copy(alpha = 0.85f),
                        startAngle = startAngle,
                        sweepAngle = 95f,
                        useCenter = false,
                        style = Stroke(
                            width = 2.5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    )
                }

                // Small tick marks along outer rim
                val tickCount = 24
                for (i in 0 until tickCount) {
                    val angleRad = (i * (360f / tickCount) * (PI / 180f)).toFloat()
                    val r1 = outerRadius + 3.dp.toPx()
                    val r2 = outerRadius + (if (i % 6 == 0) 9.dp.toPx() else 5.dp.toPx())
                    val p1 = Offset(center.x + r1 * cos(angleRad), center.y + r1 * sin(angleRad))
                    val p2 = Offset(center.x + r2 * cos(angleRad), center.y + r2 * sin(angleRad))
                    drawLine(
                        color = primaryColor.copy(alpha = if (i % 6 == 0) 0.8f else 0.35f),
                        start = p1,
                        end = p2,
                        strokeWidth = if (i % 6 == 0) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // 3. Middle Gyroscopic Track with Reactor Nodes (Counter-rotating)
            val midRadius = maxRadius * 0.68f * stateScale
            val midRotation = when (coreState) {
                AiCoreState.THINKING -> normalRotation * 3f
                else -> -normalRotation * 0.8f
            }

            rotate(midRotation, pivot = center) {
                // Circular dashed guideline
                drawCircle(
                    color = secondaryColor.copy(alpha = 0.45f),
                    radius = midRadius,
                    center = center,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))
                    )
                )

                // 8 Arc Reactor Energy Nodes (Rectangular/Triangular blocks)
                val nodeCount = 8
                for (i in 0 until nodeCount) {
                    val angleRad = (i * (360f / nodeCount) * (PI / 180f)).toFloat()
                    val nodeCenter = Offset(
                        center.x + midRadius * cos(angleRad),
                        center.y + midRadius * sin(angleRad)
                    )

                    drawCircle(
                        color = primaryColor,
                        radius = 4.dp.toPx(),
                        center = nodeCenter
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 1.8.dp.toPx(),
                        center = nodeCenter
                    )
                }
            }

            // 4. Radar Sweep Beam (Active in THINKING state)
            if (coreState == AiCoreState.THINKING) {
                rotate(scanBeamAngle, pivot = center) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color.Transparent,
                                primaryColor.copy(alpha = 0.45f)
                            ),
                            center = center
                        ),
                        startAngle = 0f,
                        sweepAngle = 45f,
                        useCenter = true
                    )
                }
            }

            // 5. Soundwave Frequency Visualizer (Active in SPEAKING or LISTENING state)
            if (coreState == AiCoreState.SPEAKING || coreState == AiCoreState.LISTENING) {
                val waveCount = 18
                val waveSpanAngle = 180f
                val startBaseAngle = 0f

                for (i in 0 until waveCount) {
                    val progress = i.toFloat() / (waveCount - 1)
                    val barAngle = startBaseAngle + progress * waveSpanAngle
                    val angleRad = (barAngle * (PI / 180f)).toFloat()

                    val waveAmp = if (coreState == AiCoreState.SPEAKING) {
                        sin(vocalWaveCycle + i * 0.6f) * 14.dp.toPx() + 16.dp.toPx()
                    } else {
                        (audioRms * 28.dp.toPx()).coerceAtLeast(4.dp.toPx())
                    }

                    val rStart = midRadius - 8.dp.toPx()
                    val rEnd = rStart + waveAmp

                    val pStart = Offset(center.x + rStart * cos(angleRad), center.y + rStart * sin(angleRad))
                    val pEnd = Offset(center.x + rEnd * cos(angleRad), center.y + rEnd * sin(angleRad))

                    drawLine(
                        color = primaryColor.copy(alpha = 0.85f),
                        start = pStart,
                        end = pEnd,
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 6. Inner Arc Reactor Ring
            val innerRingRadius = maxRadius * 0.44f * stateScale
            drawCircle(
                color = primaryColor,
                radius = innerRingRadius,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )

            // Inner triangular energy alignment accents
            rotate(-normalRotation * 1.5f, pivot = center) {
                for (i in 0 until 4) {
                    val angleRad = (i * 90f * (PI / 180f)).toFloat()
                    val p1 = Offset(center.x + (innerRingRadius - 5.dp.toPx()) * cos(angleRad), center.y + (innerRingRadius - 5.dp.toPx()) * sin(angleRad))
                    val p2 = Offset(center.x + (innerRingRadius + 5.dp.toPx()) * cos(angleRad), center.y + (innerRingRadius + 5.dp.toPx()) * sin(angleRad))
                    drawLine(
                        color = Color.White,
                        start = p1,
                        end = p2,
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }

            // 7. Glowing Core Pulsar (Center)
            val coreRadius = maxRadius * 0.28f * stateScale
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        primaryColor,
                        secondaryColor,
                        Color.Transparent
                    ),
                    center = center,
                    radius = coreRadius * 1.4f
                ),
                radius = coreRadius,
                center = center
            )

            // Ultra-bright central photon pin
            drawCircle(
                color = Color.White,
                radius = 6.dp.toPx() * (if (coreState == AiCoreState.LISTENING) (1f + audioRms * 0.5f) else 1f),
                center = center
            )
        }
    }
}
