package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.components.AiCoreState
import com.example.ui.components.ArcReactorCore
import com.example.ui.history.ChatHistoryScreen
import com.example.ui.hud.HudHeader
import com.example.ui.hud.LiveTranscriptCard
import com.example.ui.hud.QuickActionGrid
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.ArcBlue
import com.example.ui.theme.DeepSpaceBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HudBorderCyan
import com.example.ui.theme.HudSurfaceCard
import com.example.ui.theme.HudSurfaceDark
import com.example.ui.theme.HudTextPrimary
import com.example.ui.theme.HudTextSecondary
import com.example.ui.theme.NeonAccentGreen
import com.example.ui.theme.NeonWarningRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SabaMainScreen(
    viewModel: SabaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val currentScreen by viewModel.currentScreen.collectAsState()
    val aiCoreState by viewModel.aiCoreState.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val audioRms by viewModel.audioRms.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val liveUserText by viewModel.liveUserText.collectAsState()
    val liveAssistantText by viewModel.liveAssistantText.collectAsState()
    val lastAction by viewModel.lastAction.collectAsState()
    val actionStatusMessage by viewModel.actionStatusMessage.collectAsState()
    val conversationHistory by viewModel.conversationHistory.collectAsState()

    val voicePitch by viewModel.voicePitch.collectAsState()
    val speechRate by viewModel.speechRate.collectAsState()
    val language by viewModel.language.collectAsState()
    val memoryEnabled by viewModel.memoryEnabled.collectAsState()
    val contextLimit by viewModel.contextLimit.collectAsState()
    val continuousMode by viewModel.continuousMode.collectAsState()

    var isMicPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isMicPermissionGranted = isGranted
        if (isGranted) {
            viewModel.toggleListening()
        }
    }

    var showTextInputSheet by remember { mutableStateOf(false) }
    var textInputQuery by remember { mutableStateOf("") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    when (currentScreen) {
        Screen.HUD -> {
            Scaffold(
                modifier = modifier
                    .fillMaxSize()
                    .background(DeepSpaceBlack)
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                containerColor = DeepSpaceBlack
            ) { paddingValues ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // 1. Top HUD Header
                    HudHeader(
                        onOpenHistory = { viewModel.navigateTo(Screen.CHAT_HISTORY) },
                        onOpenSettings = { viewModel.navigateTo(Screen.SETTINGS) }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. Central Arc Reactor Core
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        ArcReactorCore(
                            coreState = aiCoreState,
                            audioRms = audioRms,
                            size = 250.dp,
                            onClick = {
                                if (!isMicPermissionGranted) {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    viewModel.toggleListening()
                                }
                            },
                            modifier = Modifier.testTag("arc_reactor_core")
                        )
                    }

                    // Status readout badge under Arc Reactor
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(HudSurfaceDark)
                            .border(1.dp, HudBorderCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 14.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = statusMessage.uppercase(),
                            color = when (aiCoreState) {
                                AiCoreState.LISTENING -> ElectricCyan
                                AiCoreState.SPEAKING -> NeonAccentGreen
                                AiCoreState.THINKING -> Color(0xFF00E5FF)
                                AiCoreState.ERROR -> NeonWarningRed
                                else -> HudTextSecondary
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3. Live Transcript & Response Card
                    LiveTranscriptCard(
                        userText = liveUserText,
                        assistantText = liveAssistantText,
                        action = lastAction,
                        actionStatusMessage = actionStatusMessage,
                        onReplaySpeech = { viewModel.replayCurrentSpeech() },
                        onExecuteAction = { action -> viewModel.executeActionManually(action) }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 4. Direct Protocols / Quick Intent Chips
                    QuickActionGrid(
                        onTriggerCommand = { command ->
                            viewModel.processCommand(command)
                        }
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // 5. Bottom HUD Controls (Mic button, keyboard, stop)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Keyboard input button
                        IconButton(
                            onClick = { showTextInputSheet = true },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(HudSurfaceCard)
                                .border(1.dp, HudBorderCyan, CircleShape)
                                .testTag("keyboard_input_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Keyboard,
                                contentDescription = "Type text query",
                                tint = ElectricCyan,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Central Electric-Blue Microphone Button
                        val infiniteTransition = rememberInfiniteTransition(label = "MicHalo")
                        val haloScale by infiniteTransition.animateFloat(
                            initialValue = 1f,
                            targetValue = if (isListening) 1.25f else 1.08f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1000, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "HaloScale"
                        )

                        Box(contentAlignment = Alignment.Center) {
                            // Pulsing Outer Glow Ring
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .scale(haloScale)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(
                                                (if (isListening) ElectricCyan else ArcBlue).copy(alpha = 0.45f),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            // Main Mic Button
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(
                                                if (isListening) ElectricCyan else ArcBlue,
                                                if (isListening) ArcBlue else Color(0xFF003882)
                                            )
                                        )
                                    )
                                    .border(2.dp, ElectricCyan, CircleShape)
                                    .clickable {
                                        if (!isMicPermissionGranted) {
                                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        } else {
                                            viewModel.toggleListening()
                                        }
                                    }
                                    .testTag("microphone_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.Mic,
                                    contentDescription = if (isListening) "Stop Listening" else "Activate Voice Recognition",
                                    tint = DeepSpaceBlack,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }

                        // Vocal Stop / Silence Button
                        IconButton(
                            onClick = {
                                if (isSpeaking) {
                                    viewModel.stopSpeaking()
                                } else {
                                    viewModel.replayCurrentSpeech()
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(HudSurfaceCard)
                                .border(1.dp, HudBorderCyan, CircleShape)
                                .testTag("silence_button")
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.Close,
                                contentDescription = if (isSpeaking) "Silence SABA voice" else "Clear prompt",
                                tint = if (isSpeaking) NeonWarningRed else HudTextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Keyboard Text Input Bottom Sheet
            if (showTextInputSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showTextInputSheet = false },
                    sheetState = sheetState,
                    containerColor = HudSurfaceDark,
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp)
                    ) {
                        Text(
                            text = "DIRECT TERMINAL INPUT // COMMAND",
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = textInputQuery,
                                onValueChange = { textInputQuery = it },
                                placeholder = {
                                    Text(
                                        text = "Type a command in English, Hindi, or Hinglish...",
                                        color = HudTextSecondary,
                                        fontSize = 13.sp
                                    )
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = ElectricCyan,
                                    unfocusedBorderColor = HudBorderCyan,
                                    focusedTextColor = HudTextPrimary,
                                    unfocusedTextColor = HudTextPrimary,
                                    cursorColor = ElectricCyan
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("text_query_input")
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(
                                onClick = {
                                    if (textInputQuery.isNotBlank()) {
                                        viewModel.processCommand(textInputQuery)
                                        textInputQuery = ""
                                        showTextInputSheet = false
                                    }
                                },
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(ElectricCyan)
                                    .testTag("send_query_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Send Command",
                                    tint = DeepSpaceBlack
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }

        Screen.CHAT_HISTORY -> {
            ChatHistoryScreen(
                messages = conversationHistory,
                onDeleteMessage = { id -> viewModel.deleteMessage(id) },
                onClearAll = { viewModel.clearAllHistory() },
                onBack = { viewModel.navigateTo(Screen.HUD) },
                modifier = Modifier
                    .statusBarsPadding()
                    .navigationBarsPadding()
            )
        }

        Screen.SETTINGS -> {
            SettingsScreen(
                voicePitch = voicePitch,
                speechRate = speechRate,
                language = language,
                memoryEnabled = memoryEnabled,
                contextLimit = contextLimit,
                continuousMode = continuousMode,
                isMicPermissionGranted = isMicPermissionGranted,
                onPitchChange = { viewModel.setVoicePitch(it) },
                onRateChange = { viewModel.setSpeechRate(it) },
                onLanguageChange = { viewModel.setLanguage(it) },
                onMemoryToggle = { viewModel.setMemoryEnabled(it) },
                onContextLimitChange = { viewModel.setContextLimit(it) },
                onContinuousModeToggle = { viewModel.setContinuousMode(it) },
                onRequestMicPermission = {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                onTestVoice = { viewModel.testVoiceOutput() },
                onBack = { viewModel.navigateTo(Screen.HUD) },
                modifier = Modifier
                    .statusBarsPadding()
                    .navigationBarsPadding()
            )
        }
    }
}
