package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic JARVIS Electric Cyan & Arc Reactor Blues
val ElectricCyan = Color(0xFF00F0FF)
val ElectricCyanDark = Color(0xFF00A2B3)
val ArcBlue = Color(0xFF0077FE)
val ArcBlueDark = Color(0xFF0044AA)
val DeepSpaceBlack = Color(0xFF030712)
val HudSurfaceDark = Color(0xFF080E1E)
val HudSurfaceCard = Color(0xFF0D162B)
val HudBorderCyan = Color(0x3300F0FF)
val HudTextPrimary = Color(0xFFE0F7FF)
val HudTextSecondary = Color(0xFF88A9C3)
val NeonAccentGreen = Color(0xFF00FFB2)
val NeonWarningRed = Color(0xFFFF3366)
val HologramGlow = Color(0x6600F0FF)
