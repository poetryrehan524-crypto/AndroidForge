package com.example.util

import com.example.BuildConfig

object ConfigHelper {
    fun getGeminiApiKey(): String {
        return try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            val key = field.get(null) as? String
            key?.trim() ?: ""
        } catch (e: Throwable) {
            ""
        }
    }

    fun hasValidGeminiApiKey(): Boolean {
        val key = getGeminiApiKey()
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }
}
